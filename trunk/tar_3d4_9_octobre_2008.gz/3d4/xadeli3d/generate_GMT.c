#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>

#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"

void generate_GMT_script(Widget w, caddr_t donnees, caddr_t appels)
{
    int i, j, k, nz;
    char dirplot[10];
    FILE *fscript, *fdata;
    Arg argu[4];
    int nargu, r, g, b;
    double v1, v2, truc, x, y, exa, ang1, ang2;
    XmString provis;
    ZONE *z;

    strcpy(dirplot, "PLOT1");
    i=1;
#ifdef SUN
    while ((access(dirplot, "")==0) && (i<128)) {
#else
    while ((access(dirplot, E_ACC)==0) && (i<128)) {
#endif
        i++;
        dirplot[4]=0;
        sprintf(buf, "%d", i);
        strcat(dirplot, buf);
        }
    if ((i>=128) || mkdir(dirplot, S_IRWXU | S_IRGRP | S_IXGRP)) {
        nargu=0;
        sprintf(buf, "Unable to create directory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    strcpy(buf, dirplot);
    strcat(buf, "/SCRIPT");
    fscript=fopen(buf, "w");
    if (!fscript) {
        nargu=0;
        sprintf(buf, "Unable to open file %s", buf);
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    fprintf(fscript, "PATH=/u/ibm1/ddemanet/GMT3.0/src:$PATH\n\n");
    for (nz=nzones-1; nz>=0; nz--) {
        z=&(zone[nz]);
/******* plot axes ***************/
        fprintf(fscript, "# plot axes of zone %d\n", nz);
        fprintf(fscript, "psbasemap -JX%f/%f -R%f/%f/%f/%f ", xlen, ylen,
                    xmin*ch_unit, xmax*ch_unit, ymin*ch_unit, ymax*ch_unit);
        if (nz!=nzones-1) {
            fprintf(fscript, "'-Ba%ff%f/a%ff%f:%s:neSW' ",
                 xlabel*ch_unit, xtick*ch_unit,
                 ylabel*ch_unit, ytick*ch_unit, (ch_unit==1. ? "(m)":"(km)"));
            fprintf(fscript, "-X0 -Y%f -O -K -P >> tmp.ps\n", ylen+3.);
            }
        else {
            fprintf(fscript, "'-Ba%ff%f:%s:/a%ff%f:%s:neSW' ",
                 xlabel*ch_unit, xtick*ch_unit, (ch_unit==1. ? "(m)":"(km)"),
                 ylabel*ch_unit, ytick*ch_unit, (ch_unit==1. ? "(m)":"(km)"));
            fprintf(fscript, "-X2.5 -Y2.5 -K -P > tmp.ps\n");
            }

/******** plot scalar *****************************/
        if ((z->ploted_scalar >= 0) && (z->nelem) && (z->val_min!=z->val_max)) {
            fprintf(fscript, "# plot scalar of zone %d\n", nz);
            if (z->smooth_print) {
                sprintf(buf, "%s/scalar%d.cpt", dirplot, nz);
                fdata=fopen(buf, "w");
                if (!fdata) {
                    nargu=0;
                    sprintf(buf, "Unable to open file %s", buf);
                    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                    XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                    XtSetValues(Werror, argu, nargu);
                    XtManageChild(Werror);
                    XmStringFree(provis);
                    fclose(fscript);
                    return;
                    }
                v1=z->val_min;
                for (i=0; i<N_COUL; i++) {
                    v2=z->val_min+
                       ((double)(i+1))*(z->val_max-z->val_min)/((double)N_COUL);
                    if (print_color) {
                        truc=(double)i/(double)(N_COUL-1)*PI;
                        r=(int)((sin(truc-PI/2)+1.)*127.);
                        g=(int)(sqrt(sin(truc)+0.)*255.);
                        b=(int)((sin(truc+PI/2)+1.)*127.);
                        }
                    else {
                        truc=(1.0-(double)i/(double)(N_COUL-1))*255.;
                        r=(int)(truc);
                        g=(int)(truc);
                        b=(int)(truc);
                        }
                    fprintf(fdata, "%lg %d %d %d %lg %d %d %d",
                            v1*z->units_mul_scalar, r, g, b,
                            v2*z->units_mul_scalar, r, g, b);
                    if (i==N_COUL-1)
                        fprintf(fdata," U\n");
                    else
                        if (i%2)
                            fprintf(fdata,"\n");
                        else
                            fprintf(fdata," L\n");
                    v1=v2;
                    }
                if (print_color) {
                    fprintf(fdata, "B   0   0 255\n");
                    fprintf(fdata, "F 255   0   0\n");
                    }
                else {
                    fprintf(fdata, "B 255 255 255\n");
                    fprintf(fdata, "F   0   0   0\n");
                    }
                fclose(fdata);
                fprintf(fscript, "psscale -O -K -Cscalar%d.cpt -D%f/%f/%f/1 >> tmp.ps\n",
                     nz, xlen+0.5, ylen/2., ylen-1.);
                sprintf(buf, "%s/net%d", dirplot, nz);
                fdata=fopen(buf, "w");
                if (!fdata) {
                    nargu=0;
                    sprintf(buf, "Unable to open file %s", buf);
                    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                    XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                    XtSetValues(Werror, argu, nargu);
                    XtManageChild(Werror);
                    XmStringFree(provis);
                    fclose(fscript);
                    return;
                    }
                for (i=0; i<z->nelem; i++) {
                    for (j=0; j<z->nodes_by_elem; j++) {
                        fprintf(fdata, "%d ", z->nodes_elem[j][i]-1);
                        }
                    fprintf(fdata, "\n");
                    }
                fclose(fdata);
                sprintf(buf, "%s/scalar%d", dirplot, nz);
                fdata=fopen(buf, "w");
                if (!fdata) {
                    nargu=0;
                    sprintf(buf, "Unable to open file %s", buf);
                    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                    XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                    XtSetValues(Werror, argu, nargu);
                    XtManageChild(Werror);
                    XmStringFree(provis);
                    fclose(fscript);
                    return;
                    }
                fprintf(fscript, "pscontour -JX -R -O -K -Cscalar%d.cpt -I scalar%d -Tnet%d >> tmp.ps\n",
                         nz, nz, nz);
                for (i=0; i<z->npoints; i++) {
                    v1=0.;
                    v2=0.;
                    for (j=0; j<z->nelem; j++) {
                        for (k=0; k<z->nodes_by_elem; k++) {
                            if (z->nodes_elem[k][j] == i+1) {
                                v1+=z->values[z->ploted_scalar][j];
                                v2++;
                                }
                            }
                        }
                    if (v2)
                        v1/=v2;
                    else
                        v1=0.;
                    fprintf(fdata, "%lg %lg %g\n",
                              z->pos_points[0][i]*ch_unit,
                              z->pos_points[1][i]*ch_unit,
                              v1*z->units_mul_scalar);
                    }
                fclose(fdata);
                }
            else {   /* no smooth print  */
                sprintf(buf, "%s/scalar%d.cpt", dirplot, nz);
                fdata=fopen(buf, "w");
                if (!fdata) {
                    nargu=0;
                    sprintf(buf, "Unable to open file %s", buf);
                    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                    XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                    XtSetValues(Werror, argu, nargu);
                    XtManageChild(Werror);
                    XmStringFree(provis);
                    fclose(fscript);
                    return;
                    }
                v1=z->val_min;
                for (i=0; i<N_COUL; i++) {
                    v2=z->val_min+
                       ((double)(i+1))*(z->val_max-z->val_min)/((double)N_COUL);
                    if (print_color) {
                        truc=(double)i/(double)(N_COUL-1)*PI;
                        r=(int)((sin(truc-PI/2)+1.)*127.);
                        g=(int)(sqrt(fabs(sin(truc)))*255.);
                        b=(int)((sin(truc+PI/2)+1.)*127.);
                        }
                    else {
                        truc=(1.0-(double)i/(double)(N_COUL-1))*255.;
                        r=(int)(truc);
                        g=(int)(truc);
                        b=(int)(truc);
                        }
                    fprintf(fdata, "%lg %d %d %d %lg %d %d %d",
                            v1*z->units_mul_scalar, r, g, b,
                            v2*z->units_mul_scalar, r, g, b);
                    if (i==N_COUL-1)
                        fprintf(fdata," U\n");
                    else
                        if (i%2)
                            fprintf(fdata,"\n");
                        else
                            fprintf(fdata," L\n");
                    fprintf(fscript, "psxy -M -JX -R  -G%d/%d/%d -O -K >>tmp.ps <<EOF\n", r, g, b);
                    for (k=0; k<z->nelem; k++) {
                        if ((z->values[z->ploted_scalar][k] >= v1) &&
                            (z->values[z->ploted_scalar][k] < v2)) {
                            fprintf(fscript, "> element %d\n", k);
                            for (j=0; j<z->nodes_by_elem; j++) {
                                fprintf(fscript, "%lg %lg\n",
                                  z->pos_points[0][z->nodes_elem[j][k]-1]*ch_unit,
                                  z->pos_points[1][z->nodes_elem[j][k]-1]*ch_unit);
                                }
                            }
                        }
                    fprintf(fscript, "EOF\n");
                    v1=v2;
                    }
                if (print_color) {
                    fprintf(fdata, "B   0   0 255\n");
                    r=0;
                    g=0; 
                    b=255;
                    fprintf(fscript, "psxy -M -JX -R  -G%d/%d/%d -O -K >>tmp.ps <<EOF\n", r, g, b);
                    for (i=0; i<z->nelem; i++) {
                        if (z->values[z->ploted_scalar][i] < z->val_min) {
                            fprintf(fscript, "> element %d\n", i);
                            for (j=0; j<z->nodes_by_elem; j++) {
                                fprintf(fscript, "%lg %lg\n",
                                  z->pos_points[0][z->nodes_elem[j][i]-1]*ch_unit,
                                  z->pos_points[1][z->nodes_elem[j][i]-1]*ch_unit);
                                }
                            }
                        }
                    fprintf(fscript, "EOF\n");
                    fprintf(fdata, "F 255   0   0\n");
                    r=255;
                    g=0; 
                    b=0;
                    fprintf(fscript, "psxy -M -JX -R  -G%d/%d/%d -O -K >>tmp.ps <<EOF\n", r, g, b);
                    for (i=0; i<z->nelem; i++) {
                        if (z->values[z->ploted_scalar][i] >= z->val_max) {
                            fprintf(fscript, "> element %d\n", i);
                            for (j=0; j<z->nodes_by_elem; j++) {
                                fprintf(fscript, "%lg %lg\n",
                                  z->pos_points[0][z->nodes_elem[j][i]-1]*ch_unit,
                                  z->pos_points[1][z->nodes_elem[j][i]-1]*ch_unit);
                                }
                            }
                        }
                    fprintf(fscript, "EOF\n");
                    }
                else {
                    fprintf(fdata, "B 255 255 255\n");
                    r=255;
                    g=255; 
                    b=255;
                    fprintf(fscript, "psxy -M -JX -R  -G%d/%d/%d -O -K >>tmp.ps <<EOF\n", r, g, b);
                    for (i=0; i<z->nelem; i++) {
                        if (z->values[z->ploted_scalar][i] < z->val_min) {
                            fprintf(fscript, "> element %d\n", i);
                            for (j=0; j<z->nodes_by_elem; j++) {
                                fprintf(fscript, "%lg %lg\n",
                                  z->pos_points[0][z->nodes_elem[j][i]-1]*ch_unit,
                                  z->pos_points[1][z->nodes_elem[j][i]-1]*ch_unit);
                                }
                            }
                        }
                    fprintf(fscript, "EOF\n");
                    fprintf(fdata, "F   0   0   0\n");
                    r=0;
                    g=0; 
                    b=0;
                    fprintf(fscript, "psxy -M -JX -R  -G%d/%d/%d -O -K >>tmp.ps <<EOF\n", r, g, b);
                    for (i=0; i<z->nelem; i++) {
                        if (z->values[z->ploted_scalar][i] >= z->val_max) {
                            fprintf(fscript, "> element %d\n", i);
                            for (j=0; j<z->nodes_by_elem; j++) {
                                fprintf(fscript, "%lg %lg\n",
                                  z->pos_points[0][z->nodes_elem[j][i]-1]*ch_unit,
                                  z->pos_points[1][z->nodes_elem[j][i]-1]*ch_unit);
                                }
                            }
                        }
                    fprintf(fscript, "EOF\n");
                    }
                fclose(fdata);
                fprintf(fscript, "psscale -O -K -Cscalar%d.cpt -D%f/%f/%f/1 >> tmp.ps\n",
                     nz, xlen+0.5, ylen/2., ylen-1.);
                }
            }

/******** plot vector *****************************/
        if ((z->ploted_vector >= 0) && (z->npoints)) {
            fprintf(fscript, "# plot vector of zone %d\n", nz);
            sprintf(buf, "%s/vector%d", dirplot, nz);
            fdata=fopen(buf, "w");
            if (!fdata) {
                nargu=0;
                sprintf(buf, "Unable to open file %s", buf);
                provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                XtSetValues(Werror, argu, nargu);
                XtManageChild(Werror);
                XmStringFree(provis);
                fclose(fscript);
                return;
                }
            switch (z->ploted_vector) {
                case 0 :  /*  Velocity field  */
                    fprintf(fscript, "psxy -JX -R -O -K -Sv vector%d >> tmp.ps\n", nz);
                    truc=ylen*(xmax-xmin)/xlen/(ymax-ymin);
                    for (i=0; i<z->npoints; i++) {
                        if (z->keep_vector[i]) {
                            v1=z->vel_points[0][i]*z->scale_vect
                               *xlen/(xmax-xmin);
                            v2=z->vel_points[1][i]*z->scale_vect
                               *xlen/(xmax-xmin);
                            fprintf(fdata, "%g %g %lg %lg\n", 
                                   z->pos_points[0][i]*ch_unit,
                                   z->pos_points[1][i]*ch_unit,
                                   atan2(v2*truc,v1)*180./PI,
                                   sqrt(v1*v1+v2*v2));
                            }
                        }
                    fprintf(fscript, "psxy -JX -R -O -K -Sv -N <<EOF >> tmp.ps\n", nz);
                    fprintf(fscript, "%lg %lg %lg %lg\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit, 
                           (ymax+(ymax-ymin)/ylen*0.2)*ch_unit,
                           0.,
                           z->legend_vect*z->scale_vect*xlen/(xmax-xmin));
                    fprintf(fscript, "EOF\n");
                    fprintf(fscript, "pstext -JX -R -N -O -K <<EOF >> tmp.ps\n");
                    fprintf(fscript, "%lf %lf 12 0 0 0 %10.4g m/s\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit,
                           (ymax+(ymax-ymin)/ylen*0.4)*ch_unit,
                           z->legend_vect*z->units_mul_vector);
                    fprintf(fscript, "EOF\n");
                    break;
                case 1 :  /*  displacement field  */
                    fprintf(fscript, "psxy -JX -R -O -K -Sv vector%d >> tmp.ps\n", nz);
                    truc=ylen*(xmax-xmin)/xlen/(ymax-ymin);
                    for (i=0; i<z->npoints; i++) {
                        if (z->keep_vector[i]) {
                            v1=z->disp_points[0][i]*z->scale_vect
                               *xlen/(xmax-xmin);
                            v2=z->disp_points[1][i]*z->scale_vect
                               *xlen/(xmax-xmin);
                            fprintf(fdata, "%g %g %lg %lg\n", 
                                   z->pos_points[0][i]*ch_unit,
                                   z->pos_points[1][i]*ch_unit,
                                   atan2(v2*truc,v1)*180./PI,
                                   sqrt(v1*v1+v2*v2));
                            }
                        }
                    fprintf(fscript, "psxy -JX -R -O -K -Sv -N <<EOF >> tmp.ps\n", nz);
                    fprintf(fscript, "%lg %lg %lg %lg\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit, 
                           (ymax+(ymax-ymin)/ylen*0.2)*ch_unit,
                           0.,
                           z->legend_vect*z->scale_vect*xlen/(xmax-xmin));
                    fprintf(fscript, "EOF\n");
                    fprintf(fscript, "pstext -JX -R -N -O -K <<EOF >> tmp.ps\n");
                    fprintf(fscript, "%lf %lf 12 0 0 0 %10.4g m\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit,
                           (ymax+(ymax-ymin)/ylen*0.4)*ch_unit,
                           z->legend_vect*z->units_mul_vector);
                    fprintf(fscript, "EOF\n");
                    break;
                case 2 :  /*  thermal flux  */
                    fprintf(fscript, "psxy -JX -R -O -K -Sv vector%d >> tmp.ps\n", nz);
                    truc=ylen*(xmax-xmin)/xlen/(ymax-ymin);
                    for (i=0; i<z->nelem; i++) {
                        if (z->keep_vector[i]) {
                            center_of_elem(nz, i, &x, &y);
                            x*=ch_unit;
                            y*=ch_unit;
                            v1=z->values[10][i]*z->scale_vect
                               *xlen/(xmax-xmin);
                            v2=z->values[11][i]*z->scale_vect
                               *xlen/(xmax-xmin);
                            fprintf(fdata, "%g %g %lg %lg\n", 
                                   x, y,
                                   atan2(v2*truc,v1)*180./PI,
                                   sqrt(v1*v1+v2*v2));
                            }
                        }
                    fprintf(fscript, "psxy -JX -R -O -K -Sv -N <<EOF >> tmp.ps\n", nz);
                    fprintf(fscript, "%lg %lg %lg %lg\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit, 
                           (ymax+(ymax-ymin)/ylen*0.2)*ch_unit,
                           0.,
                           z->legend_vect*z->scale_vect*xlen/(xmax-xmin));
                    fprintf(fscript, "EOF\n");
                    fprintf(fscript, "pstext -JX -R -N -O -K <<EOF >> tmp.ps\n");
                    fprintf(fscript, "%lf %lf 12 0 0 0 %10.4g Wm@+-2@+\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit,
                           (ymax+(ymax-ymin)/ylen*0.4)*ch_unit,
                           z->legend_vect*z->units_mul_vector);
                    fprintf(fscript, "EOF\n");
                    break;
                case 3 :  /*  main stresses  */
                case 4 :  /*  main deviatoric stresses  */
                    fprintf(fscript, "psvelo -JX -R -O -K -Sx%lg vector%d >> tmp.ps\n",
                              z->scale_vect*xlen/(xmax-xmin)/2.54, nz);
                    exa=ylen/(ymax-ymin)/xlen*(xmax-xmin);
                    for (i=0; i<z->nelem; i++) {
                        if (z->keep_vector[i]) {
                            truc=-z->values[21][i];
                            x=cos(truc);
                            y=sin(truc);
                            ang1=atan2(y*exa,x)*180./PI;
                            ang2=atan2(-x*exa,y)*180./PI;
                            center_of_elem(nz, i, &x, &y);
                            x*=ch_unit;
                            y*=ch_unit;
                            v1=z->values[18][i];
                            v2=z->values[19][i];
                            if (z->ploted_vector == 4) {
                                v1-=z->values[0][i];
                                v2-=z->values[0][i];
                                }
                            fprintf(fdata, "%g %g %lg %lg %lg\n", 
                                   x, y, v1, 0., ang1);
                            fprintf(fdata, "%g %g %lg %lg %lg\n", 
                                   x, y, v2, 0., ang2);
                            }
                        }
                    fprintf(fscript, "psvelo -N -JX -R -O -K -Sx%lg <<EOF >> tmp.ps\n",
                              z->scale_vect*xlen/(xmax-xmin)/2.54);
                    fprintf(fscript, "%lg %lg %lg %lg %lg\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit, 
                           (ymax+(ymax-ymin)/ylen*0.2)*ch_unit,
                           z->legend_vect, 0., 0.);
                    fprintf(fscript, "EOF\n");
                    fprintf(fscript, "pstext -JX -R -N -O -K <<EOF >> tmp.ps\n");
                    fprintf(fscript, "%lf %lf 12 0 0 0 %10.4g Pa\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit,
                           (ymax+(ymax-ymin)/ylen*0.4)*ch_unit,
                           z->legend_vect*z->units_mul_vector);
                    fprintf(fscript, "EOF\n");
                    break;
                case 5 :  /*  direction and mode of bifurcation  */
                    fprintf(fscript, "psxy -JX -R -O -K -Sv vector%d >> tmp.ps\n", nz);
                    truc=ylen*(xmax-xmin)/xlen/(ymax-ymin);
                    for (i=0; i<z->nelem; i++) {
                        if (z->keep_vector[i]) {
                            center_of_elem(nz, i, &x, &y);
                            x*=ch_unit;
                            y*=ch_unit;
                            v1=z->values[14][i]*z->scale_vect
                               *xlen/(xmax-xmin);
                            v2=z->values[15][i]*z->scale_vect
                               *xlen/(xmax-xmin);
                            fprintf(fdata, "%g %g %lg %lg\n", 
                                   x, y,
                                   atan2(v2*truc,v1)*180./PI,
                                   sqrt(v1*v1+v2*v2));
                            center_of_elem(nz, i, &x, &y);
                            v1=z->values[16][i]*z->scale_vect;
                            v2=z->values[17][i]*z->scale_vect;
                            x=(x-v1/2.)*ch_unit;
                            y=(y-v2/2.)*ch_unit;
                            v1*=(xlen/(xmax-xmin));
                            v2*=(xlen/(xmax-xmin));
                            fprintf(fdata, "%g %g %lg %lg\n", 
                                   x, y,
                                   atan2(v2*truc,v1)*180./PI,
                                   sqrt(v1*v1+v2*v2));
                            }
                        }
                    break;
                case 6 :  /*  main strain axes  */
                    fprintf(fscript, "psvelo -JX -R -O -K -Sx%lg vector%d >> tmp.ps\n",
                              z->scale_vect*xlen/(xmax-xmin)/2.54, nz);
                    exa=ylen/(ymax-ymin)/xlen*(xmax-xmin);
                    for (i=0; i<z->nelem; i++) {
                        if (z->keep_vector[i]) {
                            truc=-z->values[26][i];
                            x=cos(truc);
                            y=sin(truc);
                            ang1=atan2(y*exa,x)*180./PI;
                            ang2=atan2(-x*exa,y)*180./PI;
                            center_of_elem(nz, i, &x, &y);
                            x*=ch_unit;
                            y*=ch_unit;
                            v1=z->values[23][i];
                            v2=z->values[24][i];
     /*                       if (z->ploted_vector == 4) {
                                v1-=z->values[0][i];
                                v2-=z->values[0][i];
                                }                                      */
                            fprintf(fdata, "%g %g %lg %lg %lg\n", 
                                   x, y, v1, 0., ang1);
                            fprintf(fdata, "%g %g %lg %lg %lg\n", 
                                   x, y, v2, 0., ang2);
                            }
                        }
                    fprintf(fscript, "psvelo -N -JX -R -O -K -Sx%lg <<EOF >> tmp.ps\n",
                              z->scale_vect*xlen/(xmax-xmin)/2.54);
                    fprintf(fscript, "%lg %lg %lg %lg %lg\n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit, 
                           (ymax+(ymax-ymin)/ylen*0.2)*ch_unit,
                           z->legend_vect, 0., 0.);
                    fprintf(fscript, "EOF\n");
                    fprintf(fscript, "pstext -JX -R -N -O -K <<EOF >> tmp.ps\n");
                    fprintf(fscript, "%lf %lf 12 0 0 0 %10.4g \n",
                           (xmax+(xmax-xmin)/xlen*0.5)*ch_unit,
                           (ymax+(ymax-ymin)/ylen*0.4)*ch_unit,
                           z->legend_vect*z->units_mul_vector);
                    fprintf(fscript, "EOF\n");
                    break;
                }
            fclose(fdata);
            }

/******** plot mesh *****************************/
        if ((z->plot_mesh) && (z->nelem)) {
            fprintf(fscript, "# plot mesh of zone %d\n", nz);
            sprintf(buf, "%s/mesh%d", dirplot, nz);
            fdata=fopen(buf, "w");
            if (!fdata) {
                nargu=0;
                sprintf(buf, "Unable to open file %s", buf);
                provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                XtSetValues(Werror, argu, nargu);
                XtManageChild(Werror);
                XmStringFree(provis);
                fclose(fscript);
                return;
                }
            fprintf(fscript, "psxy -JX -R -M -O -K mesh%d >> tmp.ps\n", nz);
            for (i=0; i<z->nelem; i++) {
                fprintf(fdata,">\n");
                for (j=0; j<z->nodes_by_elem; j++) {
                    k=z->nodes_elem[j][i]-1;
                    fprintf(fdata, "%f %f\n", z->pos_points[0][k]*ch_unit,
                                              z->pos_points[1][k]*ch_unit);
                    }
                k=z->nodes_elem[0][i]-1;
                fprintf(fdata, "%f %f\n", z->pos_points[0][k]*ch_unit,
                                          z->pos_points[1][k]*ch_unit);
                }
            fclose(fdata);
            }
    
/******* plot contour of materials *****/
        if ((z->plot_contour) && (z->n_pt_contour)) {
            fprintf(fscript, "# plot contour of zone %d\n", nz);
            sprintf(buf, "%s/contour%d", dirplot, nz);
            fdata=fopen(buf, "w");
            if (!fdata) {
                nargu=0;
                sprintf(buf, "Unable to open file %s", buf);
                provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                XtSetValues(Werror, argu, nargu);
                XtManageChild(Werror);
                XmStringFree(provis);
                fclose(fscript);
                return;
                }
            fprintf(fscript, "psxy -JX -R -M -O -K contour%d >> tmp.ps\n", nz);
            i=0;
            while ((i<z->n_pt_contour) && ((j=z->pt_contour[i]-1)<0)) i++;
            fprintf(fdata,">\n");
            if (i<z->n_pt_contour) {
                fprintf(fdata, "%f %f\n", z->pos_points[0][j]*ch_unit,
                                          z->pos_points[1][j]*ch_unit);
                for (i++; i<z->n_pt_contour; i++) {
                    j=z->pt_contour[i]-1;
                    if (j>=0) {
                        fprintf(fdata, "%f %f\n", z->pos_points[0][j]*ch_unit,
                                                  z->pos_points[1][j]*ch_unit);
                        }
                    else {
                        while ((i<z->n_pt_contour) &&
                              ((j=z->pt_contour[i]-1)<0))
                            i++;
                        fprintf(fdata,">\n");
                        if (i<z->n_pt_contour) {
                            j=z->pt_contour[i]-1;
                            fprintf(fdata, "%f %f\n",
                                  z->pos_points[0][j]*ch_unit,
                                  z->pos_points[1][j]*ch_unit);
                            }
                        }
                    }
                }
            fclose(fdata);
            }

/******* plot highlighted elements *****/
        if (z->nhighlight) {
            fprintf(fscript, "# plot highlighted elements of zone %d\n", nz);
            sprintf(buf, "%s/highlight%d", dirplot, nz);
            fdata=fopen(buf, "w");
            if (!fdata) {
                nargu=0;
                sprintf(buf, "Unable to open file %s", buf);
                provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                XtSetValues(Werror, argu, nargu);
                XtManageChild(Werror);
                XmStringFree(provis);
                fclose(fscript);
                return;
                }
            r=highlight.red/256;
            g=highlight.green/256;
            b=highlight.blue/256;
            if (z->highlight_contour)
                fprintf(fscript, "psxy -JX -R -M -O -K highlight%d -W3/%d/%d/%d >> tmp.ps\n", nz, r, g, b);
            else
                fprintf(fscript, "psxy -JX -R -M -O -K highlight%d -G%d/%d/%d >> tmp.ps\n", nz, r, g, b);
            for (i=0; i<z->nhighlight; i++) {
                fprintf(fdata,">\n");
                for (j=0; j<z->nodes_by_elem; j++) {
                    k=z->nodes_elem[j][z->list_highlight[i]]-1;
                    fprintf(fdata, "%f %f\n", z->pos_points[0][k]*ch_unit,
                                              z->pos_points[1][k]*ch_unit);
                    }
                k=z->nodes_elem[0][z->list_highlight[i]]-1;
                fprintf(fdata, "%f %f\n", z->pos_points[0][k]*ch_unit,
                                          z->pos_points[1][k]*ch_unit);
                }
            fclose(fdata);
            }

/******** plot grilleH ****************/
        if (z->plotGrilleH) {
            fprintf(fscript, "# plot horizontal mesh of zone %d\n", nz);
            sprintf(buf, "%s/grilleH%d", dirplot, nz);
            fdata=fopen(buf, "w");
            if (!fdata) {
                nargu=0;
                sprintf(buf, "Unable to open file %s", buf);
                provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                XtSetValues(Werror, argu, nargu);
                XtManageChild(Werror);
                XmStringFree(provis);
                fclose(fscript);
                return;
                }
            r=grille.red/256;
            g=grille.green/256;
            b=grille.blue/256;
            fprintf(fscript, "psxy -JX -R -M -O -K grilleH%d -W3/%d/%d/%d >> tmp.ps\n", nz, r, g, b);
            for (i=0; i<nLignesH; i++) {
                for (j=0; j<LigneH[i].nSeg; j++) {
                    x=z->pos_points[0][LigneH[i].Segment[j].noeud[0]];
                    x=x+LigneH[i].Segment[j].prop[0]*
                      (z->pos_points[0][LigneH[i].Segment[j].noeud[1]]-x);
                    y=z->pos_points[1][LigneH[i].Segment[j].noeud[0]];
                    y=y+LigneH[i].Segment[j].prop[0]*
                      (z->pos_points[1][LigneH[i].Segment[j].noeud[1]]-y);
                    fprintf(fdata, ">\n%lf %lf\n", x*ch_unit, y*ch_unit);
                    x=z->pos_points[0][LigneH[i].Segment[j].noeud[2]];
                    x=x+LigneH[i].Segment[j].prop[1]*
                      (z->pos_points[0][LigneH[i].Segment[j].noeud[3]]-x);
                    y=z->pos_points[1][LigneH[i].Segment[j].noeud[2]];
                    y=y+LigneH[i].Segment[j].prop[1]*
                      (z->pos_points[1][LigneH[i].Segment[j].noeud[3]]-y);
                    fprintf(fdata, "%lf %lf\n", x*ch_unit, y*ch_unit);
                    }
                }
            fclose(fdata);
            }

/******** plot grilleV ****************/
        if (z->plotGrilleV) {
            fprintf(fscript, "# plot vertical mesh of zone %d\n", nz);
            sprintf(buf, "%s/grilleV%d", dirplot, nz);
            fdata=fopen(buf, "w");
            if (!fdata) {
                nargu=0;
                sprintf(buf, "Unable to open file %s", buf);
                provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                XtSetValues(Werror, argu, nargu);
                XtManageChild(Werror);
                XmStringFree(provis);
                fclose(fscript);
                return;
                }
            r=grille.red/256;
            g=grille.green/256;
            b=grille.blue/256;
            fprintf(fscript, "psxy -JX -R -M -O -K grilleV%d -W3/%d/%d/%d >> tmp.ps\n", nz, r, g, b);
            for (i=0; i<nLignesV; i++) {
                for (j=0; j<LigneV[i].nSeg; j++) {
                    x=z->pos_points[0][LigneV[i].Segment[j].noeud[0]];
                    x=x+LigneV[i].Segment[j].prop[0]*
                      (z->pos_points[0][LigneV[i].Segment[j].noeud[1]]-x);
                    y=z->pos_points[1][LigneV[i].Segment[j].noeud[0]];
                    y=y+LigneV[i].Segment[j].prop[0]*
                      (z->pos_points[1][LigneV[i].Segment[j].noeud[1]]-y);
                    fprintf(fdata, ">\n%lf %lf\n", x*ch_unit, y*ch_unit);
                    x=z->pos_points[0][LigneV[i].Segment[j].noeud[2]];
                    x=x+LigneV[i].Segment[j].prop[1]*
                      (z->pos_points[0][LigneV[i].Segment[j].noeud[3]]-x);
                    y=z->pos_points[1][LigneV[i].Segment[j].noeud[2]];
                    y=y+LigneV[i].Segment[j].prop[1]*
                      (z->pos_points[1][LigneV[i].Segment[j].noeud[3]]-y);
                    fprintf(fdata, "%lf %lf\n", x*ch_unit, y*ch_unit);
                    }
                }
            fclose(fdata);
            }

/******* plot title of zone *******/
        fprintf(fscript, "# plot title of zone %d\n", nz);
        fprintf(fscript, "pstext -JX -R -N -O -K <<EOF >> tmp.ps\n");
        fprintf(fscript, "%f %f 12 0 0 2 time=%ld years\n",
               (xmax+xmin)/2.*ch_unit,
               (ymax+(ymax-ymin)/ylen*1.)*ch_unit,
               (long)(zone[nz].time/3600./24./365.25));
        buf[0]=0;
        if (z->ploted_scalar >= 0) {
            strcat(buf, name_of_var[z->ploted_scalar]);
            if (z->ploted_vector >= 0)
                strcat(buf, " & ");
            }
        if (z->ploted_vector >= 0) {
            strcat(buf, name_of_vect[z->ploted_vector]);
            }
        fprintf(fscript, "%f %f 12 0 0 2 %s\n",
               (xmax+xmin)/2.*ch_unit,
               (ymax+(ymax-ymin)/ylen*0.3)*ch_unit,
               buf);
        fprintf(fscript, "EOF\n");
        fprintf(fscript, "\n");
        }
/******* plot general title ******/
    fprintf(fscript, "# plot general title\n");
    fprintf(fscript, "pstext -JX -R -N -O <<EOF >> tmp.ps\n");
    fprintf(fscript, "%f %f 14 0 1 2 %s\n",
               (xmax-xmin)/2.*ch_unit,
               (ymax+(ymax-ymin)/ylen*3.)*ch_unit,
               filename);
    fprintf(fscript, "EOF\n");
    fprintf(fscript, "\n\n gv tmp.ps\n");
    fclose(fscript);
    strcpy(buf, dirplot);
    strcat(buf, "/SCRIPT");
    chmod(buf, S_IRWXU | S_IRGRP | S_IXGRP);
    nargu=0;
    sprintf(buf, "Everithing saved in directory %s", dirplot);
    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
    XtSetValues(Werror, argu, nargu);
    XtManageChild(Werror);
    XmStringFree(provis);
    
}
