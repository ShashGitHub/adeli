#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>
#include <Xm/ToggleB.h>
#include <Xm/TextF.h>
#include <Xm/List.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <values.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"

Widget Wscalar, Wvector, Wcontour, Wmesh, Wvalmin, Wvalmax;
Widget Wscalevect, Wdecimationx, Wdecimationy, Wlegend, Wclip;
Widget Wunitssc, Wunitsve, Wsmooth;


void param_ploted_values(Widget w, caddr_t donnees, caddr_t appels)
{
    XmString provis;
    Arg argu[1];
    int nargu;

    update_values();

    XtManageChild(Wvalues);
}



void update_values(void)
{
    XmString provis;
    Arg argu[1];
    int nargu;

    XmToggleButtonSetState(Wcontour, zone[active_zone].plot_contour, False);
    XmToggleButtonSetState(Wmesh, zone[active_zone].plot_mesh, False);
    XmToggleButtonSetState(Wclip, zone[active_zone].clip_vect, False);
    XmToggleButtonSetState(Wsmooth, zone[active_zone].smooth_print, False);
    XmListSelectPos(Wscalar, zone[active_zone].ploted_scalar+2, False);
    XmListSelectPos(Wvector, zone[active_zone].ploted_vector+2, False);
    sprintf(buf, "%10.2g", zone[active_zone].val_min);
    XmTextFieldSetString(Wvalmin, buf);
    sprintf(buf, "%10.2g", zone[active_zone].val_max);
    XmTextFieldSetString(Wvalmax, buf);
    sprintf(buf, "%10.2g", zone[active_zone].scale_vect);
    XmTextFieldSetString(Wscalevect, buf);
    sprintf(buf, "%10.2g", zone[active_zone].decimation_distx*ch_unit);
    XmTextFieldSetString(Wdecimationx, buf);
    sprintf(buf, "%10.2g", zone[active_zone].decimation_disty*ch_unit);
    XmTextFieldSetString(Wdecimationy, buf);
    sprintf(buf, "%10.4g", zone[active_zone].legend_vect);
    XmTextFieldSetString(Wlegend, buf);
    sprintf(buf, "%10.4g", zone[active_zone].units_mul_scalar);
    XmTextFieldSetString(Wunitssc, buf);
    sprintf(buf, "%10.4g", zone[active_zone].units_mul_vector);
    XmTextFieldSetString(Wunitsve, buf);


}



void decimate_vectors(void)
{
    int i, j;
    float x1, y1, x2, y2;
    double x, y;

    if (zone[active_zone].ploted_vector < 0) return;
    if (zone[active_zone].ploted_vector < 2) {
/*  marque les points comme non-trait� sauf s'il sont trop grands  */
        for (i=0; i<zone[active_zone].npoints; i++) {
            if (zone[active_zone].clip_vect) {
                switch (zone[active_zone].ploted_vector) {
                    case 0 :
                        x=zone[active_zone].vel_points[0][i];
                        y=zone[active_zone].vel_points[1][i];
                        break;
                    case 1 :
                        x=zone[active_zone].disp_points[0][i];
                        y=zone[active_zone].disp_points[1][i];
                        break;
                    }
                x=sqrt(x*x+y*y);
                if (x > zone[active_zone].legend_vect)
                    zone[active_zone].keep_vector[i]=0;
                else
                    zone[active_zone].keep_vector[i]=2;
                }
            else
                zone[active_zone].keep_vector[i]=2;
            }
/*  d�s�lectionne les points superflus  */
        for (i=0; i<zone[active_zone].npoints; i++) {
            if (zone[active_zone].keep_vector[i] == 2) {
                zone[active_zone].keep_vector[i]=1;
                x1=zone[active_zone].pos_points[0][i]
                     -zone[active_zone].decimation_distx;
                y1=zone[active_zone].pos_points[1][i]
                     -zone[active_zone].decimation_disty;
                x2=zone[active_zone].pos_points[0][i]
                     +zone[active_zone].decimation_distx;
                y2=zone[active_zone].pos_points[1][i]
                     +zone[active_zone].decimation_disty;
                for (j=0; j<zone[active_zone].npoints; j++) {
                    if (zone[active_zone].keep_vector[j] == 2) {
                        if ((zone[active_zone].pos_points[0][j] > x1) &&
                               (zone[active_zone].pos_points[0][j] < x2) &&
                               (zone[active_zone].pos_points[1][j] > y1) &&
                               (zone[active_zone].pos_points[1][j] < y2)) {
                            zone[active_zone].keep_vector[j]=0;
                            }
                        }
                    }
                }
            }
        }
    else {
/*  marque les points comme non-trait� sauf s'il sont trop grands  */
        for (i=0; i<zone[active_zone].nelem; i++) {
            if (zone[active_zone].clip_vect) {
                switch (zone[active_zone].ploted_vector) {
                    case 2 :  /* thermal flux */
                        x=zone[active_zone].values[10][i];
                        y=zone[active_zone].values[11][i];
                        break;
                    case 3 :  /* main stresses  */
                        x=fabs(zone[active_zone].values[18][i]);
                        y=fabs(zone[active_zone].values[19][i]);
                        if (x>y)
                            y=0.;
                        else
                            x=0.;
                        break;
                    case 4 :  /* main deviatoric stresses  */
                        x=fabs(zone[active_zone].values[18][i]
                            -zone[active_zone].values[0][i]);
                        y=fabs(zone[active_zone].values[19][i]
                            -zone[active_zone].values[0][i]);
                        if (x>y)
                            y=0.;
                        else
                            x=0.;
                        break;
/*                    case 6 :   main strain  */
/*                        x=fabs(zone[active_zone].values[23][i]); */
/*                        y=fabs(zone[active_zone].values[24][i]);*/
/*                        if (x>y)*/
/*                            y=0.;*/
/*                        else*/
/*                            x=0.;*/
/*                        break; */
                    }
                x=sqrt(x*x+y*y);
                if (x > zone[active_zone].legend_vect)
                    zone[active_zone].keep_vector[i]=0;
                else
                    zone[active_zone].keep_vector[i]=2;
                }
            else
                zone[active_zone].keep_vector[i]=2;
            }
/*  d�s�lectionne les points superflus  */
        for (i=0; i<zone[active_zone].nelem; i++) {
            if (zone[active_zone].keep_vector[i] == 2) {
                zone[active_zone].keep_vector[i]=1;
                center_of_elem(active_zone, i, &x, &y);
                x1=x-zone[active_zone].decimation_distx;
                y1=y-zone[active_zone].decimation_disty;
                x2=x+zone[active_zone].decimation_distx;
                y2=y+zone[active_zone].decimation_disty;
                for (j=0; j<zone[active_zone].nelem; j++) {
                    if (zone[active_zone].keep_vector[j] == 2) {
                        center_of_elem(active_zone, j, &x, &y);
                        if ((x > x1) && (x < x2) &&
                               (y > y1) && (y < y2)) {
                            zone[active_zone].keep_vector[j]=0;
                            }
                        }
                    }
                }
            }
        }

}

/*  Callback pour le bouton apply */
void apply_values(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    int nsel, *sel;
    char *buf2;

    zone[active_zone].plot_contour=XmToggleButtonGetState(Wcontour);
    zone[active_zone].plot_mesh=XmToggleButtonGetState(Wmesh);
    zone[active_zone].clip_vect=XmToggleButtonGetState(Wclip);
    zone[active_zone].smooth_print=XmToggleButtonGetState(Wsmooth);

    XmListGetSelectedPos(Wscalar, &sel, &nsel);
    if (nsel)
        zone[active_zone].ploted_scalar=sel[0]-2;
    else
        zone[active_zone].ploted_scalar=-1;
    XtFree(sel);

    XmListGetSelectedPos(Wvector, &sel, &nsel);
    if (nsel)
        zone[active_zone].ploted_vector=sel[0]-2;
    else
        zone[active_zone].ploted_vector=-1;
    XtFree(sel);
    buf2=XmTextFieldGetString(Wvalmin);
    sscanf(buf2, "%f", &(zone[active_zone].val_min));
    buf2=XmTextFieldGetString(Wvalmax);
    sscanf(buf2, "%f", &(zone[active_zone].val_max));
    buf2=XmTextFieldGetString(Wscalevect);
    sscanf(buf2, "%f", &(zone[active_zone].scale_vect));
    buf2=XmTextFieldGetString(Wdecimationx);
    sscanf(buf2, "%f", &(zone[active_zone].decimation_distx));
    zone[active_zone].decimation_distx/=ch_unit;
    buf2=XmTextFieldGetString(Wdecimationy);
    sscanf(buf2, "%f", &(zone[active_zone].decimation_disty));
    zone[active_zone].decimation_disty/=ch_unit;
    buf2=XmTextFieldGetString(Wlegend);
    sscanf(buf2, "%f", &(zone[active_zone].legend_vect));
    buf2=XmTextFieldGetString(Wunitssc);
    sscanf(buf2, "%f", &(zone[active_zone].units_mul_scalar));
    buf2=XmTextFieldGetString(Wunitsve);
    sscanf(buf2, "%f", &(zone[active_zone].units_mul_vector));
    if (zone[active_zone].ploted_vector >= 0)
        decimate_vectors();

    do_affi(active_zone, zone[active_zone].w);
}

/*  Callback pour le bouton close */
void close_values(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    XtUnmanageChild(Wvalues);
}


/*  Callback pour le bouton auto */
void auto_values(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    int i, ival;
    int nsel, *sel;

    XmListGetSelectedPos(Wscalar, &sel, &nsel);
    if (nsel)
        ival=sel[0]-2;
    else
        ival=-1;
    XtFree(sel);
    if (ival<0) return;
    zone[active_zone].val_min=MAXFLOAT;
    zone[active_zone].val_max=-MAXFLOAT;
    for (i=0; i<zone[active_zone].nelem; i++) {
        if (zone[active_zone].values[ival][i] < zone[active_zone].val_min)
            zone[active_zone].val_min= zone[active_zone].values[ival][i];
        if (zone[active_zone].values[ival][i] > zone[active_zone].val_max)
            zone[active_zone].val_max=zone[active_zone].values[ival][i];
        }
    sprintf(buf, "%10.2g", zone[active_zone].val_min);
    XmTextFieldSetString(Wvalmin, buf);
    sprintf(buf, "%10.2g", zone[active_zone].val_max);
    XmTextFieldSetString(Wvalmax, buf);
}



/*  Callback pour le bouton allsc */
void all_scalar(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    int i, nsel, *sel;
    char *buf2;

    XmListGetSelectedPos(Wscalar, &sel, &nsel);
    if (nsel)
        zone[active_zone].ploted_scalar=sel[0]-2;
    else
        zone[active_zone].ploted_scalar=-1;
    XtFree(sel);
    buf2=XmTextFieldGetString(Wvalmin);
    sscanf(buf2, "%f", &(zone[active_zone].val_min));
    buf2=XmTextFieldGetString(Wvalmax);
    sscanf(buf2, "%f", &(zone[active_zone].val_max));
    buf2=XmTextFieldGetString(Wunitssc);
    sscanf(buf2, "%f", &(zone[active_zone].units_mul_scalar));
    for (i=0; i<nzones; i++) {
        zone[i].val_min=zone[active_zone].val_min;
        zone[i].val_max=zone[active_zone].val_max;
        zone[i].ploted_scalar=zone[active_zone].ploted_scalar;
        zone[i].units_mul_scalar=zone[active_zone].units_mul_scalar;
        do_affi(i, zone[i].w);
        }
}



/*  Callback pour le bouton allve */
void all_vector(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    int i, iactive, nsel, *sel;
    char *buf2;

    buf2=XmTextFieldGetString(Wscalevect);
    sscanf(buf2, "%f", &(zone[active_zone].scale_vect));
    buf2=XmTextFieldGetString(Wdecimationx);
    sscanf(buf2, "%f", &(zone[active_zone].decimation_distx));
    zone[active_zone].decimation_distx/=ch_unit;
    buf2=XmTextFieldGetString(Wdecimationy);
    sscanf(buf2, "%f", &(zone[active_zone].decimation_disty));
    zone[active_zone].decimation_disty/=ch_unit;
    buf2=XmTextFieldGetString(Wlegend);
    sscanf(buf2, "%f", &(zone[active_zone].legend_vect));
    buf2=XmTextFieldGetString(Wunitsve);
    sscanf(buf2, "%f", &(zone[active_zone].units_mul_vector));
    XmListGetSelectedPos(Wvector, &sel, &nsel);
    if (nsel)
        zone[active_zone].ploted_vector=sel[0]-2;
    else
        zone[active_zone].ploted_vector=-1;
    XtFree(sel);
    iactive=active_zone;
    for (i=0; i<nzones; i++) {
        zone[i].scale_vect=zone[active_zone].scale_vect;
        zone[i].decimation_distx=zone[active_zone].decimation_distx;
        zone[i].decimation_disty=zone[active_zone].decimation_disty;
        zone[i].legend_vect=zone[active_zone].legend_vect;
        zone[i].ploted_vector=zone[active_zone].ploted_vector;
        zone[i].clip_vect=zone[active_zone].clip_vect;
        zone[i].units_mul_vector=zone[active_zone].units_mul_vector;
        active_zone=i;
        decimate_vectors();
        active_zone=iactive;
        do_affi(i, zone[i].w);
        }
}



/*  Callback pour le bouton auto vector */
void auto_vector(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    int i, ival;
    int nsel, *sel;
    float vmax, vx, vy;

    XmListGetSelectedPos(Wvector, &sel, &nsel);
    if (nsel)
        ival=sel[0]-2;
    else
        ival=-1;
    XtFree(sel);
    zone[active_zone].decimation_distx=(xmax-xmin)/20.;
    zone[active_zone].decimation_disty=(ymax-ymin)/20.;
    if (ival<0) return;
    vmax=-MAXFLOAT;
    switch (ival) {
        case 0 :  /* velocity field  */
            for (i=0; i<zone[active_zone].npoints; i++) {
                vx=zone[active_zone].vel_points[0][i];
                vy=zone[active_zone].vel_points[1][i];
                vx=sqrt(vx*vx+vy*vy);
                if (vx > vmax)
                    vmax=vx;
                }
            break;
        case 1 :  /* displacement field  */
            for (i=0; i<zone[active_zone].npoints; i++) {
                vx=zone[active_zone].disp_points[0][i];
                vy=zone[active_zone].disp_points[1][i];
                vx=sqrt(vx*vx+vy*vy);
                if (vx > vmax)
                    vmax=vx;
                }
            break;
        case 2 :  /* thermal flux  */
            for (i=0; i<zone[active_zone].nelem; i++) {
                vx=zone[active_zone].values[10][i];
                vy=zone[active_zone].values[11][i];
                vx=sqrt(vx*vx+vy*vy);
                if (vx > vmax)
                    vmax=vx;
                }
            break;
        case 3 :  /* main stresses  */
            for (i=0; i<zone[active_zone].nelem; i++) {
                vx=fabs(zone[active_zone].values[18][i]);
                if (vx > vmax)
                    vmax=vx;
                vx=fabs(zone[active_zone].values[19][i]);
                if (vx > vmax)
                    vmax=vx;
                }
            break;
        case 4 :  /* main deviatoric stresses  */
            for (i=0; i<zone[active_zone].nelem; i++) {
                vx=fabs(zone[active_zone].values[18][i]
                    -zone[active_zone].values[0][i]);
                if (vx > vmax)
                    vmax=vx;
                vx=fabs(zone[active_zone].values[19][i]
                    -zone[active_zone].values[0][i]);
                if (vx > vmax)
                    vmax=vx;
                }
            break;
        case 5 :  /* direction and mode of bifurcation  */
            for (i=0; i<zone[active_zone].nelem; i++) {
                vx=zone[active_zone].values[14][i];
                vy=zone[active_zone].values[15][i];
                vx=sqrt(vx*vx+vy*vy);
                if (vx > vmax)
                    vmax=vx;
                vx=zone[active_zone].values[16][i];
                vy=zone[active_zone].values[17][i];
                vx=sqrt(vx*vx+vy*vy);
                if (vx > vmax)
                    vmax=vx;
                }
            break;
        case 6 :  /* main strain  */
            for (i=0; i<zone[active_zone].nelem; i++) {
                vx=fabs(zone[active_zone].values[23][i]);
                if (vx > vmax)
                    vmax=vx;
                vx=fabs(zone[active_zone].values[24][i]);
                if (vx > vmax)
                    vmax=vx;
                }
            break;
        }
    if (vmax)
        zone[active_zone].scale_vect=zone[active_zone].decimation_distx/vmax;
    else
        zone[active_zone].scale_vect=1.0;
    zone[active_zone].legend_vect=vmax;
    sprintf(buf, "%10.2g", zone[active_zone].scale_vect);
    XmTextFieldSetString(Wscalevect, buf);
    sprintf(buf, "%10.2g", zone[active_zone].decimation_distx*ch_unit);
    XmTextFieldSetString(Wdecimationx, buf);
    sprintf(buf, "%10.2g", zone[active_zone].decimation_disty*ch_unit);
    XmTextFieldSetString(Wdecimationy, buf);
    sprintf(buf, "%10.4g", zone[active_zone].legend_vect);
    XmTextFieldSetString(Wlegend, buf);
}



Widget CWvaluesDialog(Widget wparent)
{
    Widget Wdlg, Wl1, Wl2, Wl3, Wl4, Wl5, Wl6, Wl7, Wl8, Wl9, Wl10;
    Widget Wauto2, Wauto, Wapply, Wclose, Wallsc, Wallve;
    Arg argu[10];
    int nargu;
    XmString provis;

    nargu=0;
    sprintf(buf, "Ploted values parameters");
    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(argu[nargu], XmNdialogTitle, provis); nargu++;
    XtSetArg(argu[nargu], XmNhorizontalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNverticalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNautoUnmanage, False); nargu++;
    Wdlg=XmCreateFormDialog(wparent, "Ploted values parameters", argu, nargu);
    XmStringFree(provis);
    nargu=0;
    XtSetArg(argu[nargu], XmNallowResize, TRUE); nargu++;
    Wl1=CWlabel(Wdlg, "label 1", "Scalar : ", argu, nargu);
    Wl2=CWlabel(Wdlg, "label 2", "Vector : ", argu, nargu);
    Wl3=CWlabel(Wdlg, "label 3", "Min : ", argu, nargu);
    Wl4=CWlabel(Wdlg, "label 4", "Max : ", argu, nargu);
    Wl5=CWlabel(Wdlg, "label 5", "Scale : ", argu, nargu);
    Wl6=CWlabel(Wdlg, "label 6", "dist. x : ", argu, nargu);
    Wl7=CWlabel(Wdlg, "label 7", "dist. y : ", argu, nargu);
    Wl8=CWlabel(Wdlg, "label 8", "Legend value : ", argu, nargu);
    Wl9=CWlabel(Wdlg, "label 9", "Multiplier : ", argu, nargu);
    Wl10=CWlabel(Wdlg, "label 10", "Multiplier : ", argu, nargu);
    Wvalmin=CWtext(Wdlg, "valmin", 10, argu, nargu);
    Wvalmax=CWtext(Wdlg, "valmax", 10, argu, nargu);
    Wscalevect=CWtext(Wdlg, "scalevect", 10, argu, nargu);
    Wdecimationx=CWtext(Wdlg, "decimationx", 10, argu, nargu);
    Wdecimationy=CWtext(Wdlg, "decimationy", 10, argu, nargu);
    Wlegend=CWtext(Wdlg, "legend", 10, argu, nargu);
    Wunitssc=CWtext(Wdlg, "unitssc", 10, argu, nargu);
    Wunitsve=CWtext(Wdlg, "unitsve", 10, argu, nargu);
    Wapply=CWboutonP(Wdlg, "Apply", argu, nargu, apply_values);
    Wclose=CWboutonP(Wdlg, "Close", argu, nargu, close_values);
    Wauto=CWboutonP(Wdlg, "Auto", argu, nargu, auto_values);
    Wauto2=CWboutonP(Wdlg, "Auto", argu, nargu, auto_vector);
    Wallsc=CWboutonP(Wdlg, "All zones", argu, nargu, all_scalar);
    Wallve=CWboutonP(Wdlg, "All zones", argu, nargu, all_vector);

    provis=XmStringCreate("contour", XmFONTLIST_DEFAULT_TAG);
    nargu=0;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wcontour=XmCreateToggleButton(Wdlg, "contour", argu, nargu);
    XtManageChild(Wcontour);
    XmStringFree(provis);
    provis=XmStringCreate("mesh", XmFONTLIST_DEFAULT_TAG);
    nargu=0;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wmesh=XmCreateToggleButton(Wdlg, "mesh", argu, nargu);
    XtManageChild(Wmesh);
    XmStringFree(provis);
    provis=XmStringCreate("clip to legend", XmFONTLIST_DEFAULT_TAG);
    nargu=0;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wclip=XmCreateToggleButton(Wdlg, "clip", argu, nargu);
    XtManageChild(Wclip);
    XmStringFree(provis);
    provis=XmStringCreate("smooth print", XmFONTLIST_DEFAULT_TAG);
    nargu=0;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wsmooth=XmCreateToggleButton(Wdlg, "smooth", argu, nargu);
    XtManageChild(Wsmooth);
    XmStringFree(provis);

    nargu=0;
    XtSetArg(argu[nargu], XmNlistSizePolicy, XmVARIABLE); nargu++;
    XtSetArg(argu[nargu], XmNselectionPolicy, XmSINGLE_SELECT); nargu++;
    XtSetArg(argu[nargu], XmNvisibleItemCount, 6); nargu++;
    Wscalar=XmCreateScrolledList(Wdlg, "scalar", argu, nargu);
    XtManageChild(Wscalar);
    nargu=2;
    XtSetArg(argu[nargu], XmNvisibleItemCount, 7); nargu++;
    Wvector=XmCreateScrolledList(Wdlg, "vector", argu, nargu);
    XtManageChild(Wvector);

/*  regle la position des elements  */
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl1, argu, nargu);
    nargu=1;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl1); nargu++;
    XtSetValues(XtParent(Wscalar), argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftWidget, XtParent(Wscalar)); nargu++;
    XtSetValues(Wl3, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftWidget, Wl3); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wvalmin, argu, nargu);
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wvalmin); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, XtParent(Wscalar)); nargu++;
    XtSetValues(Wl4, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl4); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wvalmax, argu, nargu);
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wvalmax); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wauto, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightWidget, Wauto); nargu++;
    XtSetValues(Wallsc, argu, nargu);
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wallsc); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, XtParent(Wscalar)); nargu++;
    XtSetValues(Wl9, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl9); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wunitssc, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wunitssc); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl2, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl2); nargu++;
    XtSetValues(XtParent(Wvector), argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, XtParent(Wvector)); nargu++;
    XtSetValues(Wl5, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl5); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wscalevect, argu, nargu);
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wscalevect); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, XtParent(Wvector)); nargu++;
    XtSetValues(Wl6, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl6); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wdecimationx, argu, nargu);
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wdecimationx); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, XtParent(Wvector)); nargu++;
    XtSetValues(Wl7, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl7); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wdecimationy, argu, nargu);
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wdecimationy); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wauto2, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightWidget, Wauto2); nargu++;
    XtSetValues(Wallve, argu, nargu);
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wallve); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, XtParent(Wvector)); nargu++;
    XtSetValues(Wl10, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl10); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wunitsve, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wunitsve); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_OPPOSITE_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wvector); nargu++;
    XtSetValues(Wl8, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl8); nargu++;
    XtSetValues(Wlegend, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wlegend); nargu++;
    XtSetValues(Wclip, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wlegend); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wcontour, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wmesh, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightWidget, Wmesh); nargu++;
    XtSetValues(Wsmooth, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wcontour); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wapply, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wclose, argu, nargu);

    return(Wdlg);
}


void fill_lists(void)
{
    XmString provis;
    Arg argu[1];
    int nargu, i, n;


    nargu=0;
    XtSetArg(argu[nargu], XmNitemCount, &n); nargu++;
    XtGetValues(Wscalar, argu, nargu);
    for (i=0; i<n; i++)
        XmListDeletePos(Wscalar, 0);
    XtGetValues(Wvector, argu, nargu);
    for (i=0; i<n; i++)
        XmListDeletePos(Wvector, 0);

    provis=XmStringCreate("<none>", XmFONTLIST_DEFAULT_TAG);
    XmListAddItem(Wscalar, provis, 0);
    XmListAddItem(Wvector, provis, 0);
    XmStringFree(provis);

    for (i=0; i<nvar; i++) {
        provis=XmStringCreate(name_of_var[i], XmFONTLIST_DEFAULT_TAG);
        XmListAddItem(Wscalar, provis, 0);
        XmStringFree(provis);
        }

    for (i=0; i<nvect; i++) {
        provis=XmStringCreate(name_of_vect[i], XmFONTLIST_DEFAULT_TAG);
        XmListAddItem(Wvector, provis, 0);
        XmStringFree(provis);
        }

}
