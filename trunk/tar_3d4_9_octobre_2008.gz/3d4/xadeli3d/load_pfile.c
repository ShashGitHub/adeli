#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>

#include <stdio.h>
#include <stdlib.h>
#include <values.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"

void load_pfile(Widget w, caddr_t donnees, caddr_t appels)
{
    XtManageChild(Wload);
}

void ok_load(Widget w, caddr_t donnees, caddr_t appels)
{
    XmFileSelectionBoxCallbackStruct *fcb;
    Arg argu[3];
    int nargu, i, flsteps, flvalues;
    XmString provis;

    XtUnmanageChild(Wload);
    if (filename != NULL) {
        XtFree(filename);
        filename = NULL;
        }
    fcb = (XmFileSelectionBoxCallbackStruct *) appels;

/*  get the filename from the file selection box */
    XmStringGetLtoR(fcb->value, XmFONTLIST_DEFAULT_TAG, &filename);

/*  reinitialize and free the memory if needed  */
    initialize();

    file_in=fopen(filename, "r");
    if (!file_in) {
        nargu=0;
        sprintf(buf, "Unable to open file %s", filename);
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    nargu=0;
    if (strlen(filename) < 30)
        sprintf(buf, "xadeli:%s", filename);
    else
        sprintf(buf, "xadeli: ...%s", &(filename[strlen(filename)-30]));
    XtSetArg(argu[nargu], XmNtitle, buf); nargu++;
    XtSetValues(Wmain, argu, nargu);
    fgets(buf, DIM_BUF, file_in);
    sscanf(buf, "%d", &nvar);
    name_of_var=malloc(nvar*sizeof(char *));
    if (!name_of_var) {
        initialize();
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    for (i=0; i<nvar; i++) {
        fgets(buf, DIM_BUF, file_in);
        nargu=strlen(buf)-1;
        while ((nargu>0) && ((buf[nargu]=='\n') || (buf[nargu]==' '))) {
            buf[nargu]=0;
            nargu--;
            }
        name_of_var[i]=malloc(sizeof(char)*(strlen(buf)+1));
        if (!name_of_var[i]) {
            initialize();
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        strcpy(name_of_var[i], buf);
        }
    pos_time_step=malloc(sizeof(long *)*100);
    if (!pos_time_step) {
        initialize();
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    max_time_steps=100;
    if (!feof(file_in)) {
        pos_time_step[0]=ftell(file_in);
        time_steps_read=1;
        }
    else {
        pos_time_step[0]=0L;
        time_steps_read=0;
        }
    flsteps=0;
    if (XtIsManaged(Wsteps)) {
        flsteps=1;
        XtUnmanageChild(Wsteps);
        }
    flvalues=0;
    if (XtIsManaged(Wvalues)) {
        flvalues=1;
        XtUnmanageChild(Wvalues);
        }
    load_step(0, 0);
    fill_lists();
    if (flsteps) param_time_steps(w, donnees, appels);
    if (flvalues) param_ploted_values(w, donnees, appels);
}

void cancel_load(Widget w, caddr_t donnees, caddr_t appels)
{
    XtUnmanageChild(Wload);
}


void initialize(void) {
    int i;

    if (file_in) 
        fclose(file_in);
    file_in=NULL;

    if (pos_time_step) {
        free(pos_time_step);
        pos_time_step=NULL;
        }
    max_time_steps=0;
    time_steps_read=0;

    if (name_of_var) {
        for (i=0; i<nvar; i++)
            if (name_of_var[i])
                free(name_of_var[i]);
        free(name_of_var);
        name_of_var=NULL;
        }

    for (i=0; i< nzones; i++) 
        initialize_zone(i, 0);

    if (LigneH) {
        for (i=0; i<nLignesH; i++) {
            if (LigneH[i].Segment)
                free(LigneH[i].Segment);
            }
        free(LigneH);
        LigneH=NULL;
        }
    nLignesH=0;

    if (LigneV) {
        for (i=0; i<nLignesV; i++) {
            if (LigneV[i].Segment)
                free(LigneV[i].Segment);
            }
        free(LigneV);
        LigneV=NULL;
        }
    nLignesV=0;
}



void initialize_zone(int num_zone, int keep_some)
{
    int i;

    zone[num_zone].nstep=0;
    zone[num_zone].time=0.;
    zone[num_zone].npoints=0;
    if (zone[num_zone].pos_points) {
        for (i=0; i<zone[num_zone].dim_esp; i++)
            if (zone[num_zone].pos_points[i])
                free(zone[num_zone].pos_points[i]);
        free(zone[num_zone].pos_points);
        zone[num_zone].pos_points=NULL;
        }
    if (zone[num_zone].vel_points) {
        for (i=0; i<zone[num_zone].dim_esp; i++)
            if (zone[num_zone].vel_points[i])
                free(zone[num_zone].vel_points[i]);
        free(zone[num_zone].vel_points);
        zone[num_zone].vel_points=NULL;
        }
    if (zone[num_zone].disp_points) {
        for (i=0; i<zone[num_zone].dim_esp; i++)
            if (zone[num_zone].disp_points[i])
                free(zone[num_zone].disp_points[i]);
        free(zone[num_zone].disp_points);
        zone[num_zone].disp_points=NULL;
        }
    if (zone[num_zone].max_pos) {
        free(zone[num_zone].max_pos);
        zone[num_zone].max_pos=NULL;
        }
    if (zone[num_zone].min_pos) {
        free(zone[num_zone].min_pos);
        zone[num_zone].min_pos=NULL;
        }
    zone[num_zone].nelem=0;
    if (zone[num_zone].nodes_elem) {
        for (i=0; i<zone[num_zone].nodes_by_elem; i++)
            if (zone[num_zone].nodes_elem[i])
                free(zone[num_zone].nodes_elem[i]);
        free(zone[num_zone].nodes_elem);
        zone[num_zone].nodes_elem=NULL;
        }
    zone[num_zone].n_pt_contour=0;
    if (zone[num_zone].pt_contour) {
        free(zone[num_zone].pt_contour);
        zone[num_zone].pt_contour=NULL;
        }
    if (zone[num_zone].values) {
        for (i=0; i<nvar; i++)
            if (zone[num_zone].values[i])
                free(zone[num_zone].values[i]);
        free(zone[num_zone].values);
        zone[num_zone].values=NULL;
        }
    zone[num_zone].dim_esp=0;
    zone[num_zone].nodes_by_elem=0;
    if (zone[num_zone].keep_vector) {
        free(zone[num_zone].keep_vector);
        zone[num_zone].keep_vector=NULL;
        }
    if (!keep_some) {
        zone[num_zone].plot_contour=1;
        zone[num_zone].plot_mesh=0;
        zone[num_zone].smooth_print=1;
        zone[num_zone].ploted_scalar=-1;
        zone[num_zone].ploted_vector=-1;
        zone[num_zone].val_min=0.;
        zone[num_zone].val_max=0.;
        zone[num_zone].scale_vect=0.;
        zone[num_zone].decimation_distx=0.;
        zone[num_zone].decimation_disty=0.;
        zone[num_zone].clip_vect=0.;
        zone[num_zone].units_mul_scalar=1.;
        zone[num_zone].units_mul_vector=1.;
        zone[num_zone].nhighlight=0;
        zone[num_zone].nhighlightmax=0;
        zone[num_zone].highlight_contour=0;
        zone[num_zone].list_highlight=NULL;
        zone[num_zone].plotGrilleV=0;
        zone[num_zone].plotGrilleH=0;
        }
}



void load_step(int step, int keep_some)
{
    Arg argu[3];
    int nargu;
    XmString provis;
    long ldummy;
    int i, j, has_topo, topostep;
    int nnode, ndime, npcont, npcnt;
    char *tmp;

    if (!time_steps_read) {
        nargu=0;
        sprintf(buf, "Invalid file");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }

    if (step >= time_steps_read) {
        fseek(file_in, pos_time_step[time_steps_read-1], SEEK_SET);
        while ((step >= time_steps_read)  && skip_step());
        }
    else
        fseek(file_in, pos_time_step[step], SEEK_SET);

    if (step >= time_steps_read) {
        nargu=0;
        sprintf(buf, "Invalid time step");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }

    initialize_zone(active_zone, keep_some);
    zone[active_zone].nstep=step;

    fgets(buf, DIM_BUF, file_in);
    sscanf(buf, "%d", &has_topo);
    if (has_topo)
        read_topo();
    else {
        topostep=step;
        while ((topostep > 0) && !has_topo) {
            topostep--;
            fseek(file_in, pos_time_step[topostep], SEEK_SET);
            fgets(buf, DIM_BUF, file_in);
            sscanf(buf, "%d", &has_topo);
            }
        if (!has_topo) {
            nargu=0;
            sprintf(buf, "Invalid file format - No topology");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        read_topo();
        fseek(file_in, pos_time_step[step], SEEK_SET);
        fgets(buf, DIM_BUF, file_in);
        }

    fgets(buf, DIM_BUF, file_in);
    sscanf(buf, "%ld %lf", &ldummy, &(zone[active_zone].time));

    zone[active_zone].pos_points=malloc(zone[active_zone].dim_esp
                                        *sizeof(float *));
    if (!zone[active_zone].pos_points) {
        initialize_zone(active_zone, 0);
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    zone[active_zone].vel_points=malloc(zone[active_zone].dim_esp
                                        *sizeof(float *));
    if (!zone[active_zone].vel_points) {
        initialize_zone(active_zone, 0);
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    zone[active_zone].disp_points=malloc(zone[active_zone].dim_esp
                                        *sizeof(float *));
    if (!zone[active_zone].disp_points) {
        initialize_zone(active_zone, 0);
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    zone[active_zone].max_pos=malloc(zone[active_zone].dim_esp
                                        *sizeof(float));
    if (!zone[active_zone].max_pos) {
        initialize_zone(active_zone, 0);
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    zone[active_zone].min_pos=malloc(zone[active_zone].dim_esp
                                        *sizeof(float));
    if (!zone[active_zone].min_pos) {
        initialize_zone(active_zone, 0);
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    for (i=0; i<zone[active_zone].dim_esp; i++) {
        zone[active_zone].pos_points[i]=malloc(zone[active_zone].npoints
                                               *sizeof(float));
        if (!zone[active_zone].pos_points[i]) {
            initialize_zone(active_zone, 0);
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        zone[active_zone].vel_points[i]=malloc(zone[active_zone].npoints
                                               *sizeof(float));
        if (!zone[active_zone].vel_points[i]) {
            initialize_zone(active_zone, 0);
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        zone[active_zone].disp_points[i]=malloc(zone[active_zone].npoints
                                               *sizeof(float));
        if (!zone[active_zone].disp_points[i]) {
            initialize_zone(active_zone, 0);
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        }
    if (zone[active_zone].npoints > zone[active_zone].nelem) 
        zone[active_zone].keep_vector=malloc(zone[active_zone].npoints
                                           *sizeof(char));
    else
        zone[active_zone].keep_vector=malloc(zone[active_zone].nelem
                                           *sizeof(char));
    if (!zone[active_zone].keep_vector) {
        initialize_zone(active_zone, 0);
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    for (j=0; j<zone[active_zone].dim_esp; j++) {
        zone[active_zone].max_pos[j]=-MAXFLOAT;
        zone[active_zone].min_pos[j]=MAXFLOAT;
        }
    for (i=0; i<zone[active_zone].npoints; i++) {
        fgets(buf, DIM_BUF, file_in);
        tmp=strtok(buf, " ,;\t");
        for (j=0; j<zone[active_zone].dim_esp; j++) {
            tmp=strtok(NULL, " ,;\t");
            sscanf(tmp, "%f", &(zone[active_zone].pos_points[j][i]));
            if (zone[active_zone].pos_points[j][i] 
                           > zone[active_zone].max_pos[j])
                zone[active_zone].max_pos[j]=zone[active_zone].pos_points[j][i];
            if (zone[active_zone].pos_points[j][i] 
                           < zone[active_zone].min_pos[j])
                zone[active_zone].min_pos[j]=zone[active_zone].pos_points[j][i];
            }
        for (j=0; j<zone[active_zone].dim_esp; j++) {
            tmp=strtok(NULL, " ,;\t");
            sscanf(tmp, "%f", &(zone[active_zone].vel_points[j][i]));
            }
        for (j=0; j<zone[active_zone].dim_esp; j++) {
            tmp=strtok(NULL, " ,;\t");
            sscanf(tmp, "%f", &(zone[active_zone].disp_points[j][i]));
            }
        }


    zone[active_zone].values=malloc((nvar+13)*sizeof(float *));
    if (!zone[active_zone].values) {
        initialize_zone(active_zone, 0);
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    for (i=0; i<nvar+13; i++) {
        zone[active_zone].values[i]=malloc(zone[active_zone].nelem
                                               *sizeof(float));
        if (!zone[active_zone].values[i]) {
            initialize_zone(active_zone, 0);
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        }
    for (i=0; i<zone[active_zone].nelem; i++) {
        fgets(buf, DIM_BUF, file_in);
        tmp=strtok(buf, " ,;\t");
        for (j=0; j<nvar+13; j++) {
            tmp=strtok(NULL, " ,;\t");
            sscanf(tmp, "%f", &(zone[active_zone].values[j][i]));
            }
        }
    do_affi(active_zone, zone[active_zone].w);
}


int skip_step(void)
{
    Arg argu[3];
    int nargu;
    XmString provis;
    int i, has_topo, topostep;
    int nelem, npoin, nnode, ndime, npcont, npcnt, nlignes;
    long *tmp_pos;

    fgets(buf, DIM_BUF, file_in);
    sscanf(buf, "%d", &has_topo);
    if (has_topo) {
        fgets(buf, DIM_BUF, file_in);
        sscanf(buf, "%d %d %d %d %d %d", &nelem, &npoin, &nnode,
                                         &ndime, &npcont, &npcnt);
        for (i=0; i<nelem; i++)
            fgets(buf, DIM_BUF, file_in);
        fgets(buf, DIM_BUF, file_in);
        if (npcont) {
            nlignes=floor((double)npcont/10.0+.95);
            for (i=0; i< nlignes; i++)
                fgets(buf, DIM_BUF, file_in);
            }
        if (npcnt) {
            nlignes=floor((double)npcnt/10.0+.95);
            for (i=0; i< nlignes; i++)
                fgets(buf, DIM_BUF, file_in);
            }
        }
    else {
        topostep=time_steps_read-1;
        while ((topostep > 0) && !has_topo) {
            topostep--;
            fseek(file_in, pos_time_step[topostep], SEEK_SET);
            fgets(buf, DIM_BUF, file_in);
            sscanf(buf, "%d", &has_topo);
            }
        if (!has_topo) {
            nargu=0;
            sprintf(buf, "Invalid file format - No topology");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        fgets(buf, DIM_BUF, file_in);
        sscanf(buf, "%d %d %d %d %d %d", &nelem, &npoin, &nnode,
                                         &ndime, &npcont, &npcnt);
        fseek(file_in, pos_time_step[time_steps_read-1], SEEK_SET);
        fgets(buf, DIM_BUF, file_in);
        }

    fgets(buf, DIM_BUF, file_in);
    for (i=0; i<npoin; i++)
        fgets(buf, DIM_BUF, file_in);
    for (i=0; i<nelem; i++)
        fgets(buf, DIM_BUF, file_in);
    if (feof(file_in))
        return(0);
    if (time_steps_read >= max_time_steps-1) {
        tmp_pos=realloc(pos_time_step, (max_time_steps+100)*sizeof(long *));
        if (!tmp_pos)
            return(0);
        pos_time_step=tmp_pos;
        max_time_steps+=100;
        }
    pos_time_step[time_steps_read]=ftell(file_in);
    time_steps_read++;
    return(1);
}



void read_topo(void)
{
    int i, j, idummy, npcnt, nlignes;
    char *tmp;
    Arg argu[3];
    int nargu;
    XmString provis;

    fgets(buf, DIM_BUF, file_in);
    sscanf(buf, "%d %d %d %d %d %d", &(zone[active_zone].nelem),
                                     &(zone[active_zone].npoints),
                                     &(zone[active_zone].nodes_by_elem),
                                     &(zone[active_zone].dim_esp),
                                     &(zone[active_zone].n_pt_contour),
                                     &npcnt);
    zone[active_zone].nodes_elem=malloc(zone[active_zone].nodes_by_elem
                                        *sizeof(int *));
    if (!zone[active_zone].nodes_elem) {
        initialize_zone(active_zone, 0);
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    for (i=0; i<zone[active_zone].nodes_by_elem; i++) {
        zone[active_zone].nodes_elem[i]=malloc(zone[active_zone].nelem
                                               *sizeof(int));
        if (!zone[active_zone].nodes_elem[i]) {
            initialize_zone(active_zone, 0);
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        }
    for (i=0; i<zone[active_zone].nelem; i++) {
        fgets(buf, DIM_BUF, file_in);
        tmp=strtok(buf, " ,;\t");
        tmp=strtok(NULL, " ,;\t");
        for (j=0; j<zone[active_zone].nodes_by_elem; j++) {
            tmp=strtok(NULL, " ,;\t");
            sscanf(tmp, "%d", &(zone[active_zone].nodes_elem[j][i]));
            }
        }
    fgets(buf, DIM_BUF, file_in);
    if (zone[active_zone].n_pt_contour) {
        zone[active_zone].pt_contour=malloc(zone[active_zone].n_pt_contour
                                            *sizeof(int));
        if (!zone[active_zone].pt_contour) {
            initialize_zone(active_zone, 0);
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            return;
            }
        fgets(buf, DIM_BUF, file_in);
        tmp=strtok(buf, " ,;\t");
        for (i=0; i<zone[active_zone].n_pt_contour; i++) {
            if (!tmp) {
                fgets(buf, DIM_BUF, file_in);
                tmp=strtok(buf, " ,;\t");
                }
            sscanf(tmp, "%d", &(zone[active_zone].pt_contour[i]));
            tmp=strtok(NULL, " ,;\t");
            }
        }
    if (npcnt) {
        nlignes=floor((double)npcnt/10.0+.95);
        for (i=0; i< nlignes; i++)
            fgets(buf, DIM_BUF, file_in);
        }
}
