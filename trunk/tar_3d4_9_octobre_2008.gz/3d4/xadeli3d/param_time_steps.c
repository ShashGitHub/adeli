#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>
#include <Xm/TextF.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"

Widget Wstep_asked, Wstep_info;



void param_time_steps(Widget w, caddr_t donnees, caddr_t appels)
{
    XmString provis;
    Arg argu[1];
    int nargu;

    sprintf(buf, "At least %d time-steps.", time_steps_read);
    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
    nargu=0;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    XtSetValues(Wstep_info, argu, nargu);
    XmStringFree(provis);

    sprintf(buf, "%d", zone[active_zone].nstep);
    XmTextFieldSetString(Wstep_asked, buf);

    XtManageChild(Wsteps);
}


/*  Callback pour le bouton apply */
void apply_steps(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    Arg argu[3];
    int nargu, i;
    char *buf2;
    XmString provis;

    buf2=XmTextFieldGetString(Wstep_asked);
    sscanf(buf2, "%d", &i);
    load_step(i, 1);
    sprintf(buf, "At least %d time-steps.", time_steps_read);
    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
    nargu=0;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    XtSetValues(Wstep_info, argu, nargu);
    XmStringFree(provis);
}

/*  Callback pour le bouton close */
void close_steps(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    XtUnmanageChild(Wsteps);
}



Widget CWstepsDialog(Widget wparent)
{
    Widget Wdlg, Wl1, Wapply, Wclose;
    Arg argu[6];
    int nargu;
    XmString provis;

    nargu=0;
    sprintf(buf, "Time-steps parameters");
    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(argu[nargu], XmNdialogTitle, provis); nargu++;
    XtSetArg(argu[nargu], XmNhorizontalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNverticalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNautoUnmanage, False); nargu++;
    Wdlg=XmCreateFormDialog(wparent, "Time-steps parameters", argu, nargu);
    XmStringFree(provis);
    nargu=0;
    XtSetArg(argu[nargu], XmNallowResize, TRUE); nargu++;
    Wstep_info=CWlabel(Wdlg, "label info", "", argu, nargu);
    Wl1=CWlabel(Wdlg, "label 1", "Desired time-step : ", argu, nargu);
    Wapply=CWboutonP(Wdlg, "Apply", argu, nargu, apply_steps);
    Wclose=CWboutonP(Wdlg, "Close", argu, nargu, close_steps);
    Wstep_asked=CWtext(Wdlg, "step", 10, argu, nargu);

/*  regle la position des elements  */
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wstep_info, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wstep_info); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl1, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl1); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wstep_asked, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wstep_asked); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wapply, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wclose, argu, nargu);

    return(Wdlg);
}
