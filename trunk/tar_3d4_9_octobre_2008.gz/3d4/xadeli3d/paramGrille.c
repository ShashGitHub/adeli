#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>
#include <Xm/TextF.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#define INCR_ALLOC 100
#include "xadeli.h"

Widget WxminH, WxmaxH, WyminH, WymaxH, WinterH;
Widget WxminV, WxmaxV, WyminV, WymaxV, WinterV;
Widget WaffiH, WaffiV, Wredg, Wgreeng, Wblueg;


void free_grille(void)
{
    int i;

    if (LigneH) {
        for (i=0; i<nLignesH; i++) {
            if (LigneH[i].Segment)
                free(LigneH[i].Segment);
            }
        free(LigneH);
        LigneH=NULL;
        }
    nLignesH=0;

    if (LigneV) {
        for (i=0; i<nLignesV; i++) {
            if (LigneV[i].Segment)
                free(LigneV[i].Segment);
            }
        free(LigneV);
        LigneV=NULL;
        }
    nLignesV=0;
}

int add_seg(LIGNE *ligne, SEGMENT *segment)
{
    Arg argu[3];
    int nargu, i;
    XmString provis;

    if (ligne->nSeg >= ligne->nSegMax) {
        ligne->nSegMax+=INCR_ALLOC;
        ligne->Segment=realloc(ligne->Segment, ligne->nSegMax*sizeof(SEGMENT));
        if (!ligne->Segment) {
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            free_grille();
            return 1;
            }
        }
    i=ligne->nSeg;
    ligne->Segment[i].noeud[0]=segment->noeud[0];
    ligne->Segment[i].noeud[1]=segment->noeud[1];
    ligne->Segment[i].noeud[2]=segment->noeud[2];
    ligne->Segment[i].noeud[3]=segment->noeud[3];
    ligne->Segment[i].prop[0]=segment->prop[0];
    ligne->Segment[i].prop[1]=segment->prop[1];
    ligne->nSeg++;
    return 0;
}


void calcule_grille(void)
{
    Arg argu[3];
    int nargu;
    XmString provis;
    int i, j, iface, n1, n2, n3;
    double x, y, b1, a2, b2, x1, x2, y1, y2;
    SEGMENT seg;

    free_grille();

    nLignesH=(ymaxH-yminH)/interH+1;
    LigneH=malloc(sizeof(LIGNE)*nLignesH);
    if (!LigneH) {
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        free_grille();
        return;
        }

    nLignesV=(xmaxV-xminV)/interV+1;
    LigneV=malloc(sizeof(LIGNE)*nLignesV);
    if (!LigneV) {
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        free_grille();
        return;
        }

    for (i=0, b1=yminH; i<nLignesH; i++, b1+=interH) {
        LigneH[i].nSeg=0;
        LigneH[i].nSegMax=0;
        LigneH[i].Segment=NULL;
        for (j=0; j<zone[active_zone].nelem; j++) {
            n1=zone[active_zone].nodes_elem[0][j]-1;
            n2=zone[active_zone].nodes_elem[1][j]-1;
            n3=zone[active_zone].nodes_elem[2][j]-1;
            iface=0;

            x1=zone[active_zone].pos_points[0][n1];
            y1=zone[active_zone].pos_points[1][n1];
            x2=zone[active_zone].pos_points[0][n2];
            y2=zone[active_zone].pos_points[1][n2];
            if (((b1>=y1)&&(b1<=y2))||((b1>=y2)&&(b1<=y1)))
                if (y1!=y2) {
                    if (fabs(y2-y1) > fabs(x2-x1)) {
                        seg.prop[iface/2]=(b1-y1)/(y2-y1);
                        x=x1+seg.prop[iface/2]*(x2-x1);
                        }
                    else {
                        a2=(y2-y1)/(x2-x1);
                        b2=y1-a2*x1;
                        x=(b1-b2)/a2;
                        seg.prop[iface/2]=(x-x1)/(x2-x1);
                        }
                    if ((x>=xminH) && (x<=xmaxH)) {
                        seg.noeud[iface]=n1;
                        seg.noeud[iface+1]=n2;
                        iface+=2;
                        }
                    }
            x1=zone[active_zone].pos_points[0][n2];
            y1=zone[active_zone].pos_points[1][n2];
            x2=zone[active_zone].pos_points[0][n3];
            y2=zone[active_zone].pos_points[1][n3];
            if (((b1>=y1)&&(b1<=y2))||((b1>=y2)&&(b1<=y1)))
                if (y1!=y2) {
                    if (fabs(y2-y1) > fabs(x2-x1)) {
                        seg.prop[iface/2]=(b1-y1)/(y2-y1);
                        x=x1+seg.prop[iface/2]*(x2-x1);
                        }
                    else {
                        a2=(y2-y1)/(x2-x1);
                        b2=y1-a2*x1;
                        x=(b1-b2)/a2;
                        seg.prop[iface/2]=(x-x1)/(x2-x1);
                        }
                    if ((x>=xminH) && (x<=xmaxH)) {
                        seg.noeud[iface]=n2;
                        seg.noeud[iface+1]=n3;
                        iface+=2;
                        }
                    }
            if (iface==4) iface=1;
            x1=zone[active_zone].pos_points[0][n3];
            y1=zone[active_zone].pos_points[1][n3];
            x2=zone[active_zone].pos_points[0][n1];
            y2=zone[active_zone].pos_points[1][n1];
            if (((b1>=y1)&&(b1<=y2))||((b1>=y2)&&(b1<=y1)))
                if (y1!=y2) {
                    if (fabs(y2-y1) > fabs(x2-x1)) {
                        seg.prop[iface/2]=(b1-y1)/(y2-y1);
                        x=x1+seg.prop[iface/2]*(x2-x1);
                        }
                    else {
                        a2=(y2-y1)/(x2-x1);
                        b2=y1-a2*x1;
                        x=(b1-b2)/a2;
                        seg.prop[iface/2]=(x-x1)/(x2-x1);
                        }
                    if ((x>=xminH) && (x<=xmaxH)) {
                        seg.noeud[iface]=n3;
                        seg.noeud[iface+1]=n1;
                        iface+=2;
                        }
                    }
            if ((iface==4)||(iface==1))
                if (add_seg(&(LigneH[i]), &seg)) return;
            }
        }


    for (i=0, b1=xminV; i<nLignesV; i++, b1+=interV) {
        LigneV[i].nSeg=0;
        LigneV[i].nSegMax=0;
        LigneV[i].Segment=NULL;
        for (j=0; j<zone[active_zone].nelem; j++) {
            n1=zone[active_zone].nodes_elem[0][j]-1;
            n2=zone[active_zone].nodes_elem[1][j]-1;
            n3=zone[active_zone].nodes_elem[2][j]-1;
            iface=0;

            x1=zone[active_zone].pos_points[0][n1];
            y1=zone[active_zone].pos_points[1][n1];
            x2=zone[active_zone].pos_points[0][n2];
            y2=zone[active_zone].pos_points[1][n2];
            if (((b1>=x1)&&(b1<=x2))||((b1>=x2)&&(b1<=x1)))
                if (x1!=x2) {
                    if (fabs(x2-x1) > fabs(y2-y1)) {
                        seg.prop[iface/2]=(b1-x1)/(x2-x1);
                        y=y1+seg.prop[iface/2]*(y2-y1);
                        }
                    else {
                        a2=(x2-x1)/(y2-y1);
                        b2=x1-a2*y1;
                        y=(b1-b2)/a2;
                        seg.prop[iface/2]=(y-y1)/(y2-y1);
                        }
                    if ((y>=yminV) && (y<=ymaxV)) {
                        seg.noeud[iface]=n1;
                        seg.noeud[iface+1]=n2;
                        iface+=2;
                        }
                    }
            x1=zone[active_zone].pos_points[0][n2];
            y1=zone[active_zone].pos_points[1][n2];
            x2=zone[active_zone].pos_points[0][n3];
            y2=zone[active_zone].pos_points[1][n3];
            if (((b1>=x1)&&(b1<=x2))||((b1>=x2)&&(b1<=x1)))
                if (x1!=x2) {
                    if (fabs(x2-x1) > fabs(y2-y1)) {
                        seg.prop[iface/2]=(b1-x1)/(x2-x1);
                        y=y1+seg.prop[iface/2]*(y2-y1);
                        }
                    else {
                        a2=(x2-x1)/(y2-y1);
                        b2=x1-a2*y1;
                        y=(b1-b2)/a2;
                        seg.prop[iface/2]=(y-y1)/(y2-y1);
                        }
                    if ((y>=yminV) && (y<=ymaxV)) {
                        seg.noeud[iface]=n2;
                        seg.noeud[iface+1]=n3;
                        iface+=2;
                        }
                    }
            if (iface>2) iface=1;
            x1=zone[active_zone].pos_points[0][n3];
            y1=zone[active_zone].pos_points[1][n3];
            x2=zone[active_zone].pos_points[0][n1];
            y2=zone[active_zone].pos_points[1][n1];
            if (((b1>=x1)&&(b1<=x2))||((b1>=x2)&&(b1<=x1)))
                if (x1!=x2) {
                    if (fabs(x2-x1) > fabs(y2-y1)) {
                        seg.prop[iface/2]=(b1-x1)/(x2-x1);
                        y=y1+seg.prop[iface/2]*(y2-y1);
                        }
                    else {
                        a2=(x2-x1)/(y2-y1);
                        b2=x1-a2*y1;
                        y=(b1-b2)/a2;
                        seg.prop[iface/2]=(y-y1)/(y2-y1);
                        }
                    if ((y>=yminV) && (y<=ymaxV)) {
                        seg.noeud[iface]=n3;
                        seg.noeud[iface+1]=n1;
                        iface+=2;
                        }
                    }
            if ((iface==4)||(iface==1))
                if (add_seg(&(LigneV[i]), &seg)) return;
            }
        }

}

void update_grille(void)
{
    sprintf(buf, "%10.2f", xminH*ch_unit);
    XmTextFieldSetString(WxminH, buf);
    sprintf(buf, "%10.2f", xmaxH*ch_unit);
    XmTextFieldSetString(WxmaxH, buf);
    sprintf(buf, "%10.2f", yminH*ch_unit);
    XmTextFieldSetString(WyminH, buf);
    sprintf(buf, "%10.2f", ymaxH*ch_unit);
    XmTextFieldSetString(WymaxH, buf);
    sprintf(buf, "%10.2f", interH*ch_unit);
    XmTextFieldSetString(WinterH, buf);
    sprintf(buf, "%10.2f", xminV*ch_unit);
    XmTextFieldSetString(WxminV, buf);
    sprintf(buf, "%10.2f", xmaxV*ch_unit);
    XmTextFieldSetString(WxmaxV, buf);
    sprintf(buf, "%10.2f", yminV*ch_unit);
    XmTextFieldSetString(WyminV, buf);
    sprintf(buf, "%10.2f", ymaxV*ch_unit);
    XmTextFieldSetString(WymaxV, buf);
    sprintf(buf, "%10.2f", interV*ch_unit);
    XmTextFieldSetString(WinterV, buf);

    if (zone[active_zone].plotGrilleH) {
        XmToggleButtonSetState(WaffiH, True, False);
        }
    else {
        XmToggleButtonSetState(WaffiH, False, False);
        }
    if (zone[active_zone].plotGrilleV) {
        XmToggleButtonSetState(WaffiV, True, False);
        }
    else {
        XmToggleButtonSetState(WaffiV, False, False);
        }

    sprintf(buf, "%u", grille.red);
    XmTextFieldSetString(Wredg, buf);
    sprintf(buf, "%u", grille.green);
    XmTextFieldSetString(Wgreeng, buf);
    sprintf(buf, "%u", grille.blue);
    XmTextFieldSetString(Wblueg, buf);
}


void param_grille(Widget w, caddr_t donnees, caddr_t appels)
{
    update_grille();
    XtManageChild(Wgrille);
}


/*  Callback pour le bouton apply */
void apply_grille(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    Arg argu[3];
    int nargu, i, changed;
    char *buf2;
    XmString provis;
    double tmp;
    unsigned short red, green, blue;
    Colormap cmap;
    Display *dpy;

    changed=0;
    buf2=XmTextFieldGetString(WxminH);
    tmp=atof(buf2)/ch_unit;
    if (tmp != xminH) {
        xminH=tmp;
        changed=1;
        }
    XtFree(buf2);
    buf2=XmTextFieldGetString(WxmaxH);
    tmp=atof(buf2)/ch_unit;
    if (tmp != xmaxH) {
        xmaxH=tmp;
        changed=1;
        }
    XtFree(buf2);
    buf2=XmTextFieldGetString(WyminH);
    tmp=atof(buf2)/ch_unit;
    if (tmp != yminH) {
        yminH=tmp;
        changed=1;
        }
    XtFree(buf2);
    buf2=XmTextFieldGetString(WymaxH);
    tmp=atof(buf2)/ch_unit;
    if (tmp != ymaxH) {
        ymaxH=tmp;
        changed=1;
        }
    XtFree(buf2);
    buf2=XmTextFieldGetString(WinterH);
    tmp=atof(buf2)/ch_unit;
    if (tmp != interH) {
        interH=tmp;
        changed=1;
        }
    XtFree(buf2);

    buf2=XmTextFieldGetString(WxminV);
    tmp=atof(buf2)/ch_unit;
    if (tmp != xminV) {
        xminV=tmp;
        changed=1;
        }
    XtFree(buf2);
    buf2=XmTextFieldGetString(WxmaxV);
    tmp=atof(buf2)/ch_unit;
    if (tmp != xmaxV) {
        xmaxV=tmp;
        changed=1;
        }
    XtFree(buf2);
    buf2=XmTextFieldGetString(WyminV);
    tmp=atof(buf2)/ch_unit;
    if (tmp != yminV) {
        yminV=tmp;
        changed=1;
        }
    XtFree(buf2);
    buf2=XmTextFieldGetString(WymaxV);
    tmp=atof(buf2)/ch_unit;
    if (tmp != ymaxV) {
        ymaxV=tmp;
        changed=1;
        }
    XtFree(buf2);
    buf2=XmTextFieldGetString(WinterV);
    tmp=atof(buf2)/ch_unit;
    if (tmp != interV) {
        interV=tmp;
        changed=1;
        }
    XtFree(buf2);

    if (changed) calcule_grille();

    zone[active_zone].plotGrilleH=XmToggleButtonGetState(WaffiH);
    zone[active_zone].plotGrilleV=XmToggleButtonGetState(WaffiV);

    buf2=XmTextFieldGetString(Wredg);
    red=atoi(buf2);
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wgreeng);
    green=atoi(buf2);
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wblueg);
    blue=atoi(buf2);
    XtFree(buf2);

    if ((red!=grille.red) ||
             (green!=grille.green) ||
             (blue!=grille.blue)) {
        dpy=XtDisplay(Wmain);
        cmap=XDefaultColormap(dpy, DefaultScreen(dpy));
        grille.red=red;
        grille.green=green;
        grille.blue=blue;
        grille.flags=DoRed | DoGreen | DoBlue;
        XAllocColor(dpy, cmap, &grille);
        changed=1;
        }

    if (changed)
        for (i=0; i<nzones; i++)
            do_affi(i, zone[i].w);
    else
        do_affi(active_zone, zone[active_zone].w);

}

/*  Callback pour le bouton close */
void close_grille(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    XtUnmanageChild(Wgrille);
}


/*  Callback pour le bouton compute */
void compute_grille(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    xminH=xmaxH=0.;
    apply_grille(w, donnees, appels);
}

/*  Callback pour le bouton auto */
void auto_grille(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    xminH=xmin;
    xmaxH=xmax;
    yminH=ymin;
    ymaxH=ymax;
    interH=(ymaxH-yminH)/10.;
    xminV=xmin;
    xmaxV=xmax;
    yminV=ymin;
    ymaxV=ymax;
    interV=(xmaxV-xminV)/10.;
    update_grille();
}



Widget CWgrilleDialog(Widget wparent)
{
    Widget Wdlg, Wl1, Wl2, Wl3, Wl4, Wl5, Wl6, Wl7, Wl8, Wapply, Wclose, Wauto;
    Widget Wl9, Wl10, Wl11, Wcompute;
    Arg argu[7];
    int nargu;
    XmString provis;

    nargu=0;
    sprintf(buf, "Mesh parameters");
    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(argu[nargu], XmNdialogTitle, provis); nargu++;
    XtSetArg(argu[nargu], XmNhorizontalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNverticalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNautoUnmanage, False); nargu++;
    Wdlg=XmCreateFormDialog(wparent, "Mesh parameters", argu, nargu);
    XmStringFree(provis);
    nargu=0;
    XtSetArg(argu[nargu], XmNallowResize, TRUE); nargu++;
    Wl1=CWlabel(Wdlg, "label 1", "Red", argu, nargu);
    Wl2=CWlabel(Wdlg, "label 2", "Green", argu, nargu);
    Wl3=CWlabel(Wdlg, "label 3", "Blue", argu, nargu);
    Wl4=CWlabel(Wdlg, "label 4", "Interval", argu, nargu);
    Wl5=CWlabel(Wdlg, "label 5", "y max", argu, nargu);
    Wl6=CWlabel(Wdlg, "label 6", "y min", argu, nargu);
    Wl7=CWlabel(Wdlg, "label 7", "x max", argu, nargu);
    Wl8=CWlabel(Wdlg, "label 8", "x min", argu, nargu);
    Wl9=CWlabel(Wdlg, "label 9", "Display", argu, nargu);
    Wl10=CWlabel(Wdlg, "label 10", "Horizontal", argu, nargu);
    Wl11=CWlabel(Wdlg, "label 11", "Vertical", argu, nargu);
    Wapply=CWboutonP(Wdlg, "Apply", argu, nargu, apply_grille);
    Wcompute=CWboutonP(Wdlg, "Compute", argu, nargu, compute_grille);
    Wauto=CWboutonP(Wdlg, "Auto", argu, nargu, auto_grille);
    Wclose=CWboutonP(Wdlg, "Close", argu, nargu, close_grille);
    WxminH=CWtext(Wdlg, "xminH", 10, argu, nargu);
    WxmaxH=CWtext(Wdlg, "xmaxH", 10, argu, nargu);
    WyminH=CWtext(Wdlg, "yminH", 10, argu, nargu);
    WymaxH=CWtext(Wdlg, "ymaxH", 10, argu, nargu);
    WinterH=CWtext(Wdlg, "interH", 10, argu, nargu);
    WxminV=CWtext(Wdlg, "xminV", 10, argu, nargu);
    WxmaxV=CWtext(Wdlg, "xmaxV", 10, argu, nargu);
    WyminV=CWtext(Wdlg, "yminV", 10, argu, nargu);
    WymaxV=CWtext(Wdlg, "ymaxV", 10, argu, nargu);
    WinterV=CWtext(Wdlg, "interV", 10, argu, nargu);
    Wredg=CWtext(Wdlg, "redg", 10, argu, nargu);
    Wgreeng=CWtext(Wdlg, "greeng", 10, argu, nargu);
    Wblueg=CWtext(Wdlg, "blueg", 10, argu, nargu);
    provis=XmStringCreate("", XmFONTLIST_DEFAULT_TAG);
    nargu=1;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    WaffiH=XmCreateToggleButton(Wdlg, "affiH", argu, nargu);
    WaffiV=XmCreateToggleButton(Wdlg, "affiV", argu, nargu);
    XmStringFree(provis);
    XtManageChild(WaffiH);
    XtManageChild(WaffiV);


/*  regle la position des elements  */
    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wapply, argu, nargu);
    nargu=1;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wapply); nargu++;
    XtSetValues(Wcompute, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftWidget, Wcompute); nargu++;
    XtSetValues(Wauto, argu, nargu);
    nargu=1;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wclose, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, Wapply); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wredg, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wredg); nargu++;
    XtSetValues(Wgreeng, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wgreeng); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wblueg, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, Wredg); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_OPPOSITE_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wredg); nargu++;
    XtSetValues(Wl1, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wgreeng); nargu++;
    XtSetValues(Wl2, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wblueg); nargu++;
    XtSetValues(Wl3, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, Wl1); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl4, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl4); nargu++;
    XtSetValues(WinterH, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, WinterH); nargu++;
    XtSetValues(WinterV, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, WinterH); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightWidget, WinterH); nargu++;
    XtSetValues(Wl5, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl5); nargu++;
    XtSetValues(WymaxH, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, WymaxH); nargu++;
    XtSetValues(WymaxV, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, WymaxH); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightWidget, WinterH); nargu++;
    XtSetValues(Wl6, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl6); nargu++;
    XtSetValues(WyminH, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, WyminH); nargu++;
    XtSetValues(WyminV, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, WyminH); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightWidget, WinterH); nargu++;
    XtSetValues(Wl7, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl7); nargu++;
    XtSetValues(WxmaxH, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, WxmaxH); nargu++;
    XtSetValues(WxmaxV, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, WxmaxH); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightWidget, WinterH); nargu++;
    XtSetValues(Wl8, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl8); nargu++;
    XtSetValues(WxminH, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, WxminH); nargu++;
    XtSetValues(WxminV, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, WxminH); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightWidget, WinterH); nargu++;
    XtSetValues(Wl9, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_OPPOSITE_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, WxminH); nargu++;
    XtSetValues(WaffiH, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, WxminV); nargu++;
    XtSetValues(WaffiV, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNbottomWidget, WaffiH); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_OPPOSITE_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, WxminH); nargu++;
    XtSetValues(Wl10, argu, nargu);
    nargu=4;
    XtSetArg(argu[nargu], XmNleftWidget, WxminV); nargu++;
    XtSetValues(Wl11, argu, nargu);

    return(Wdlg);
}
