#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>
#include <Xm/TextF.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN
#include "xadeli.h"

/*  Creation d'un bouton  */
Widget CWboutonP(Wparent, nom, argu, nargu, proc)
Widget Wparent;
char nom[];
Arg *argu;
int nargu;
void (*proc)();
{
    Widget Wid;

    Wid=XtCreateManagedWidget(nom, xmPushButtonWidgetClass,
                              Wparent, argu, nargu);
    XtAddCallback(Wid, XmNactivateCallback, proc, NULL);
    return(Wid);
}

/*  Insere une ligne dans un menu deroulant  */
Widget InsereElemMenu(Wmenu, titre, proc_action)
Widget Wmenu;
char titre[];
void (*proc_action)();
{
    Widget Welem;

    Welem=XtCreateManagedWidget(titre, xmPushButtonWidgetClass, Wmenu, NULL, 0);
    XtAddCallback(Welem, XmNactivateCallback, proc_action, titre);
    return(Welem);
}

/* Insere un separateur dans un menu */
void InsereSeparMenu(Wmenu)
Widget Wmenu;
{
/*  On ajoute un separateur  */
    XtCreateManagedWidget("frontiere", xmSeparatorWidgetClass, Wmenu, NULL, 0);
}

/*  Creation d'un widget Label  */
Widget CWlabel(Wparent, nom, texte, argu, nargu)
Widget Wparent;
char nom[], texte[];
Arg *argu;
int nargu;
{
    Widget Wlabel;
    XmString provis;

    provis=XmStringCreate(texte, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wlabel=XtCreateManagedWidget(nom, xmLabelWidgetClass, Wparent, argu, nargu);
    XmStringFree(provis);
    return(Wlabel);
}

/*  Creation d'un widget Text  */
Widget CWtext(Wparent, nom, width, argu, nargu)
Widget Wparent;
char nom[];
Arg *argu;
int width, nargu;
{
    Widget Wtext;

    nargu=0;
    XtSetArg(argu[nargu], XmNcolumns, width); nargu++;
    Wtext=XmCreateTextField(Wparent, nom, argu, nargu);
    XtManageChild(Wtext);
    return(Wtext);
}

/*  Creation d'un menu deroulant  */
Widget CWMderoulant(Wparent, titre, intitule, raccourci)
Widget Wparent;
char titre[], intitule[];
char raccourci;
{
    Arg argu[1];
    int nargu;
    Widget Wcascade, Wmenu;

/*  Creation du bouton cascade  */
    nargu=0;
    XtSetArg(argu[nargu], XmNmnemonic, raccourci); nargu++;
    Wcascade=XmCreateCascadeButton(Wparent, titre, argu, nargu);
    XtManageChild(Wcascade);
/*  Creation du menu  */
    Wmenu=XmCreatePulldownMenu(Wparent, intitule, NULL, 0);
/*  Definition du bouton correspondant sur la barre  */
    nargu=0;
    XtSetArg(argu[nargu], XmNsubMenuId, Wmenu); nargu++;
    XtSetValues(Wcascade, argu, nargu);

    return(Wmenu);
}

/*  Creation de la barre de menu  */
Widget CWbarre(Wparent)
Widget Wparent;
{
    Widget Wbarre;
    Arg argu[1];
    int nargu;

/*  Creation de la barre  */
    nargu=0;
    Wbarre=XmCreateMenuBar(Wparent, "menu", argu, nargu);
    XtManageChild(Wbarre);
    return(Wbarre);
}

/*  Creation de la fenetre principale  */
Widget CWmainw(wparent, nom, largeur, hauteur)
Widget wparent;
char *nom;
int largeur, hauteur;
{
    Widget Wid;
    Arg argu[4];
    int nargu;

    nargu=0;
    XtSetArg(argu[nargu], XmNwidth, largeur); nargu++;
    XtSetArg(argu[nargu], XmNheight, hauteur); nargu++;
    XtSetArg(argu[nargu], XmNshadowThickness, 3); nargu++;
    XtSetArg(argu[nargu], XmNshowSeparator, True); nargu++;
    Wid=XmCreateMainWindow(wparent, nom, argu, nargu);
    XtManageChild(Wid);
    return(Wid);
}


int main(int argc, char **argv)
{
    Widget Wmain_motif, Wmenu_bar, Wmenu_fichier, Wmenu_parameter;
    Arg argu[6];
    int nargu, i;
    Colormap cmap;
    Display *dpy;
    unsigned long fore;
    XmString provis;
    double truc;


/*  Initialisation des variables globales */
    filename=NULL;
    file_in=NULL;
    pos_time_step=NULL;
    max_time_steps=0;
    time_steps_read=0;
    ch_unit=0.001;
    print_color=0;
    xmin=-100000.;
    xmax=2000000.;
    xtick=100000.;
    xlabel=400000.;
    ymin=-200000.;
    ymax=100000.;
    ytick=50000.;
    ylabel=100000.;
    xlen=15.;
    ylen=5.;
    nvect=7;
    name_of_vect=malloc(nvect*sizeof(char *));
    if (!name_of_vect) {
        printf("Unable to allocate memory");
        exit(-1);
        }
    name_of_vect[0]="Velocity field";
    name_of_vect[1]="Displacement field";
    name_of_vect[2]="Thermal flux";
    name_of_vect[3]="Main stresses";
    name_of_vect[4]="Main deviatoric stresses";
    name_of_vect[5]="Direction & mode of bifurcation";
    name_of_vect[6]="Main strain axes";
    LigneH=NULL;
    LigneV=NULL;
    nLignesH=nLignesV=0;


/*  Initialisation du Toolkit  */
    Wmain=XtInitialize(argv[0], "xadeli", NULL, 0, &argc, argv);

/*  Parametres du widget principal  */
    nargu=0;
    XtSetArg(argu[nargu], XmNallowShellResize, TRUE); nargu++;
    XtSetValues(Wmain, argu, nargu);

/*  Creation de la MainWindow Motif  */
    Wmain_motif=CWmainw(Wmain, "conteneur", 600, 400);

/*  Creation de la barre de menu  */
    Wmenu_bar=CWbarre(Wmain_motif);
/*  Creation du menu deroulant File  */
    Wmenu_fichier=CWMderoulant(Wmenu_bar, "File", "File", 'F');
    InsereElemMenu(Wmenu_fichier, "Load", load_pfile);
    InsereSeparMenu(Wmenu_fichier);
    InsereElemMenu(Wmenu_fichier, "GMT script", generate_GMT_script);
    InsereSeparMenu(Wmenu_fichier);
    InsereElemMenu(Wmenu_fichier, "Quit", quitter);
/*  Creation du menu deroulant Parameters  */
    Wmenu_fichier=CWMderoulant(Wmenu_bar, "Parameters", "Parameters", 'P');
    InsereElemMenu(Wmenu_fichier, "Axes", param_axes);
    InsereSeparMenu(Wmenu_fichier);
    InsereElemMenu(Wmenu_fichier, "Time steps", param_time_steps);
    InsereElemMenu(Wmenu_fichier, "Ploted values", param_ploted_values);
    InsereElemMenu(Wmenu_fichier, "Highlight elements", param_highlight);
    InsereElemMenu(Wmenu_fichier, "Mesh", param_grille);
    InsereSeparMenu(Wmenu_fichier);
    InsereElemMenu(Wmenu_fichier, "Add zone", param_add_zone);
    InsereElemMenu(Wmenu_fichier, "Delete zone", param_delete_zone);

/*  Creation de la PanedWindow (correspondra a la WorkRegion)  */
    nargu=0;
    XtSetArg(argu[nargu], XmNseparatorOn, TRUE); nargu++;
    XtSetArg(argu[nargu], XmNallowResize, TRUE); nargu++;
    Wpaned=XtCreateManagedWidget("Panneau", xmPanedWindowWidgetClass,
                                      Wmain_motif, argu, nargu);

/* avec 1 zone pour commencer */
    nzones=0;
    active_zone=0;
    Create_zone();

/*  Indique quels sont les widgets crees parmi les 5  */
    XmMainWindowSetAreas(Wmain_motif, Wmenu_bar, (Widget) NULL,
                           (Widget) NULL, (Widget) NULL, Wpaned);

/*  Creation de la fenetre de selection de fichier pour ouvrir  */
    nargu=0;
    provis=XmStringCreate("p*", XmFONTLIST_DEFAULT_TAG);
    XtSetArg(argu[nargu], XmNpattern, provis); nargu++;
    Wload=XmCreateFileSelectionDialog(Wmenu_bar, "Load", argu, nargu);
    XmStringFree(provis);
    XtAddCallback(Wload, XmNokCallback, ok_load, NULL);
    XtAddCallback(Wload, XmNcancelCallback, cancel_load, NULL);

/*  Creation de la fenetre d'erreur  */
    nargu=0;
    XtSetArg(argu[nargu], XmNdialogType, XmDIALOG_ERROR); nargu++;
    XtSetArg(argu[nargu], XmNmessageAlignment, XmALIGNMENT_CENTER); nargu++;
    Werror=XmCreateErrorDialog(Wmain, "Error", argu, nargu);

/*  Creation de la boite de dialogue Axes parameters  */
    Waxes=CWaxesDialog(Wmain);

/*  Creation de la boite de dialogue time-steps parameters  */
    Wsteps=CWstepsDialog(Wmain);

/*  Creation de la boite de dialogue highlight elements */
    Whighlight=CWhighlightDialog(Wmain);

/*  Creation de la boite de dialogue grille */
    Wgrille=CWgrilleDialog(Wmain);

/*  Creation de la boite de dialogue Ploted values parameters  */
    Wvalues=CWvaluesDialog(Wmain);
    fill_lists();


/*  Realisation du widget principal  */
    XtRealizeWidget(Wmain);

/*  allocation de la couleur rouge  */
    dpy=XtDisplay(Wmain);
    cmap=XDefaultColormap(dpy, DefaultScreen(dpy));
    red.red=65535;
    red.green=0;
    red.blue=0;
    red.flags=DoRed | DoGreen | DoBlue;
    XAllocColor(dpy, cmap, &red);
/*  allocation de la couleur noire */
    black.red=0;
    black.green=0;
    black.blue=0;
    black.flags=DoRed | DoGreen | DoBlue;
    XAllocColor(dpy, cmap, &black);
/*  allocation de la couleur highlight */
    highlight.red=65535;
    highlight.green=0;
    highlight.blue=0;
    highlight.flags=DoRed | DoGreen | DoBlue;
    XAllocColor(dpy, cmap, &highlight);
/*  allocation de la couleur grille */
    grille.red=65535;
    grille.green=65535;
    grille.blue=65535;
    grille.flags=DoRed | DoGreen | DoBlue;
    XAllocColor(dpy, cmap, &grille);
/*  allocation des couleurs de la palette */
    for (i=0; i<N_COUL; i++) {
        truc=fabs((double)i/(double)(N_COUL-1)*PI);
        palette[i].red=(int)((sin(truc-PI/2)+1.)*32767.);
        palette[i].green=(int)(sqrt(sin(truc)+0.)*65535.);
        palette[i].blue=(int)((sin(truc+PI/2)+1.)*32767.);
        palette[i].flags=DoRed | DoGreen | DoBlue;
        XAllocColor(dpy, cmap, &(palette[i]));
        }


/*  Traitement des evenements  */
    XtMainLoop();

}



void quitter(Widget w, caddr_t donnees, caddr_t appels)
{
    XtCloseDisplay(XtDisplay(w));
    exit(0);
}


