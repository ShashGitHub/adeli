#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>
#include <Xm/TextF.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"


void param_add_zone(Widget w, caddr_t donnees, caddr_t appels)
{

    Create_zone();
}

void param_delete_zone(Widget w, caddr_t donnees, caddr_t appels)
{
    int i;
    XmString provis;
    Arg argu[3];
    int nargu;

    if (nzones<=1) {
        nargu=0;
        sprintf(buf, "1 zone minimum");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }
    XtUnrealizeWidget(zone[active_zone].w);
    initialize_zone(active_zone, 0);
    for (i=active_zone; i<nzones-1; i++) {
        zone[i].w=zone[i+1].w;
        zone[i].nstep=zone[i+1].nstep;
        zone[i].time=zone[i+1].time;
        zone[i].dim_esp=zone[i+1].dim_esp;
        zone[i].nodes_by_elem=zone[i+1].nodes_by_elem;
        zone[i].npoints=zone[i+1].npoints;
        zone[i].pos_points=zone[i+1].pos_points;
        zone[i].vel_points=zone[i+1].vel_points;
        zone[i].disp_points=zone[i+1].disp_points;
        zone[i].max_pos=zone[i+1].max_pos;
        zone[i].min_pos=zone[i+1].min_pos;
        zone[i].nelem=zone[i+1].nelem;
        zone[i].nodes_elem=zone[i+1].nodes_elem;
        zone[i].n_pt_contour=zone[i+1].n_pt_contour;
        zone[i].pt_contour=zone[i+1].pt_contour;
        zone[i].values=zone[i+1].values;
        zone[i].plot_contour=zone[i+1].plot_contour;
        zone[i].plot_mesh=zone[i+1].plot_mesh;
        zone[i].smooth_print=zone[i+1].smooth_print;
        zone[i].ploted_scalar=zone[i+1].ploted_scalar;
        zone[i].ploted_vector=zone[i+1].ploted_vector;
        zone[i].val_min=zone[i+1].val_min;
        zone[i].val_max=zone[i+1].val_max;
        zone[i].keep_vector=zone[i+1].keep_vector;
        zone[i].scale_vect=zone[i+1].scale_vect;
        zone[i].decimation_distx=zone[i+1].decimation_distx;
        zone[i].decimation_disty=zone[i+1].decimation_disty;
        zone[i].clip_vect=zone[i+1].clip_vect;
        zone[i].units_mul_scalar=zone[i+1].units_mul_scalar;
        zone[i].units_mul_vector=zone[i+1].units_mul_vector;
        zone[i].nhighlight=zone[i+1].nhighlight;
        zone[i].nhighlightmax=zone[i+1].nhighlightmax;
        zone[i].highlight_contour=zone[i+1].highlight_contour;
        if (zone[i].list_highlight)
            free(zone[i].list_highlight);
        zone[i].list_highlight=zone[i+1].list_highlight;
        zone[i].plotGrilleV=zone[i+1].plotGrilleV;
        zone[i].plotGrilleH=zone[i+1].plotGrilleH;
        }
    nzones--;
    if (active_zone >= nzones)
        active_zone=nzones-1;
}
