#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"

void Create_zone(void)
{
    XmString provis;
    Arg argu[3];
    int nargu;


    if (nzones >= MAX_ZONES) {
        nargu=0;
        sprintf(buf, "No more than %d zones", nzones);
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        return;
        }

    nargu=0;
    XtSetArg(argu[nargu], XmNallowResize, TRUE); nargu++;
    XtSetArg(argu[nargu], XmNheight, 100); nargu++;

    zone[nzones].w=XtCreateManagedWidget("Dessin", xmDrawingAreaWidgetClass, 
                             Wpaned, argu, nargu);
    XtAddCallback(zone[nzones].w, XmNexposeCallback, affi_zone, NULL);
    XtAddCallback(zone[nzones].w, XmNinputCallback, input_zone, NULL);
    initialize_zone(nzones, 0);

    nzones++;
}
