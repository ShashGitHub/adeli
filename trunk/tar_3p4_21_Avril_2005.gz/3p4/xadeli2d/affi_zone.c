#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"
#define LEN_ARROW 8.
#define WIDTH_ARROW 3.

void affi_zone(Widget w, caddr_t donnees, caddr_t appels)
{
    XmDrawingAreaCallbackStruct *truc;
    XEvent *ev;
    int num_zone, i;

    truc=(XmDrawingAreaCallbackStruct *) appels;
    ev=truc->event;
    if (ev->xexpose.count == 0) {
        num_zone=-1;
        for (i=0; i<nzones; i++)
            if (zone[i].w==w) num_zone=i;
        if (num_zone >= 0)
            do_affi(num_zone, w);
        }

}


void center_of_elem(int nzone, int i, double *x, double *y)
{
    int j, k;

    *x=0.;
    *y=0.;
    for (j=0; j < zone[nzone].nodes_by_elem; j++) {
        k=zone[nzone].nodes_elem[j][i]-1;
        *x+=zone[nzone].pos_points[0][k];
        *y+=zone[nzone].pos_points[1][k];
        }
    *x/=(double)zone[nzone].nodes_by_elem; 
    *y/=(double)zone[nzone].nodes_by_elem; 
}


void DrawArrow(Display *dpy, Window win, GC gc, int x1, int y1, int x2, int y2)
{
    double x, y, l;
    XPoint liste_points[3];

    XDrawLine(dpy, win, gc, x1, y1, x2, y2);
    x=x2-x1;
    y=y2-y1;
    l=sqrt(x*x+y*y);
    if (l) {
        x=x/l;
        y=y/l;
        }
    liste_points[0].x=x2-(int)(LEN_ARROW*x
                              -WIDTH_ARROW*y);
    liste_points[0].y=y2-(int)(LEN_ARROW*y
                              +WIDTH_ARROW*x);
    liste_points[1].x=x2;
    liste_points[1].y=y2;
    liste_points[2].x=x2-(int)(LEN_ARROW*x
                              +WIDTH_ARROW*y);
    liste_points[2].y=y2-(int)(LEN_ARROW*y
                              -WIDTH_ARROW*x);
    XFillPolygon(dpy, win, gc, liste_points, 3,
          Convex, CoordModeOrigin);
}



void do_affi(int num_zone, Widget w)
{
    Display *dpy;
    Window win;
    XGCValues gcv;
    GC gc;
    unsigned long gcmask;
    Dimension height, width;
    XFontStruct *pol_prop;
    GContext gc_id;
    Arg argu[4];
    int nargu;
    XmString provis;
    int height_char, length_str, tmp_len, tmp_len2;
    int i, j, k, x1, y1, x2, y2, x3, y3;
    double ax, bx, ay, by, x, y, l, s, cosa, sina, s_cosa, s_sina, x0, y0;
    ZONE *z;
    XPoint *liste_points;

    z=&(zone[num_zone]);
    dpy=XtDisplay(w);
    win=XtWindow(w);
    XClearWindow(dpy, win);

    nargu=0;
    XtSetArg(argu[nargu], XmNheight, &height); nargu++;
    XtSetArg(argu[nargu], XmNwidth, &width); nargu++;
    XtGetValues(w, argu, nargu);

    gcv.line_width=1;
    gcv.function=GXcopy;
    gcmask=GCLineWidth | GCFunction;
    gc=XCreateGC(dpy, win, gcmask, &gcv);
    gc_id=XGContextFromGC(gc);
    pol_prop=XQueryFont(dpy, gc_id);
    height_char=pol_prop->ascent+pol_prop->descent;

    sprintf(buf, "step %d, t = %ld years",
              zone[num_zone].nstep,
              (long)(zone[num_zone].time/3600./24./365.25));
    length_str=XTextWidth(pol_prop, buf, strlen(buf));
    if (num_zone==active_zone)
        XSetForeground(dpy, gc, red.pixel);
    XDrawString(dpy, win, gc, (width-length_str)/2, pol_prop->ascent+2,
                buf, strlen(buf));
    XSetForeground(dpy, gc, black.pixel);

    sprintf(buf, "%d", (int)floor(ymin*ch_unit+.5));
    tmp_len=XTextWidth(pol_prop, buf, strlen(buf));
    sprintf(buf, "%d", (int)floor(ymax*ch_unit+.5));
    i=XTextWidth(pol_prop, buf, strlen(buf));
    if (i>tmp_len) tmp_len=i;
    sprintf(buf, "%d", (int)(xmax*ch_unit));
    tmp_len2=XTextWidth(pol_prop, buf, strlen(buf));
    ax=(double)((int)width-10-tmp_len2/2-2-tmp_len-6)/(xmax-xmin);
    bx=tmp_len+6-ax*xmin;
    ay=(double)(height_char+3-(int)height+height_char+5)/(ymax-ymin);
    by=height_char+3-ay*ymax;

    x1=ax*xmin+bx;
    y1=ay*ymin+by;
    x2=ax*xmax+bx;
    XDrawLine(dpy, win, gc, x1, y1, x2, y1);
    y=floor(xmin/xtick)*xtick;
    if (y<xmin) y+=xtick;
    for (x=y; x<=xmax; x+=xtick) {
        x1=ax*x+bx;
        XDrawLine(dpy, win, gc, x1, y1, x1, y1+2);
        }
    y=floor(xmin/xlabel)*xlabel;
    if (y<xmin) y+=xlabel;
    for (x=y; x<=xmax; x+=xlabel) {
        x1=ax*x+bx;
        XDrawLine(dpy, win, gc, x1, y1, x1, y1+4);
        sprintf(buf, "%d", (int)floor(x*ch_unit+.5));
        tmp_len=XTextWidth(pol_prop, buf, strlen(buf));
        XDrawString(dpy, win, gc, x1-tmp_len/2, y1+height_char+3,
                buf, strlen(buf));
        }

    x1=ax*xmin+bx;
    y1=ay*ymin+by;
    y2=ay*ymax+by;
    XDrawLine(dpy, win, gc, x1, y1, x1, y2);
    x=floor(ymin/ytick)*ytick;
    if (x<ymin) x+=ytick;
    for (y=x; y<=ymax; y+=ytick) {
        y1=ay*y+by;
        XDrawLine(dpy, win, gc, x1, y1, x1-2, y1);
        }
    x=floor(ymin/ylabel)*ylabel;
    if (x<ymin) x+=ylabel;
    for (y=x; y<=ymax; y+=ylabel) {
        y1=ay*y+by;
        XDrawLine(dpy, win, gc, x1, y1, x1-4, y1);
        sprintf(buf, "%d", (int)floor(y*ch_unit+.5));
        tmp_len=XTextWidth(pol_prop, buf, strlen(buf));
        XDrawString(dpy, win, gc, x1-tmp_len-6, y1+pol_prop->ascent/2,
                buf, strlen(buf));
        }

    liste_points=malloc(sizeof(XPoint)*4);
    if (!liste_points) {
        nargu=0;
        sprintf(buf, "Unable to allocate memory");
        provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
        XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
        XtSetValues(Werror, argu, nargu);
        XtManageChild(Werror);
        XmStringFree(provis);
        }
    else {
        x1=(int)width-11;
        x2=x1+7;
        y1=(int)height-height_char-9;
        y2=(height_char+7-(int)height+height_char+9)/N_COUL;
        liste_points[0].x=x1;
        liste_points[1].x=x2;
        liste_points[2].x=x2;
        liste_points[3].x=x1;
        for (i=0; i<N_COUL; i++) {
            liste_points[0].y=y1;
            liste_points[1].y=y1;
            y1+=y2;
            liste_points[2].y=y1;
            liste_points[3].y=y1;
            XSetForeground(dpy, gc, palette[i].pixel);
            XFillPolygon(dpy, win, gc, liste_points, 4,
                           Convex, CoordModeOrigin);
            }
        free(liste_points);
        XSetForeground(dpy, gc, black.pixel);
        }

/******** plot scalar *****************************/
    if ((z->ploted_scalar >= 0) && (z->nelem) && (z->val_min!=z->val_max)) {
        liste_points=malloc(sizeof(XPoint)*(z->nodes_by_elem));
        if (!liste_points) {
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            }
        else {
            for (i=0; i<z->nelem; i++) {
                for (j=0; j<z->nodes_by_elem; j++) {
                    k=z->nodes_elem[j][i]-1;
                    liste_points[j].x=ax*z->pos_points[0][k]+bx;
                    liste_points[j].y=ay*z->pos_points[1][k]+by;
                    }
                nargu=(z->values[z->ploted_scalar][i] - z->val_min) /
                      (z->val_max - z->val_min) * N_COUL;
                if (nargu < 0)
                    nargu=0;
                else if (nargu >= N_COUL)
                    nargu=N_COUL-1;
                XSetForeground(dpy, gc, palette[nargu].pixel);
                XFillPolygon(dpy, win, gc, liste_points, z->nodes_by_elem,
                           Convex, CoordModeOrigin);
                }
            free(liste_points);
            XSetForeground(dpy, gc, black.pixel);
            }
        }

/******** plot vector *****************************/
    if ((z->ploted_vector >= 0) && (z->npoints)) {
        liste_points=malloc(sizeof(XPoint)*3);
        if (!liste_points) {
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            }
        else {
            switch (z->ploted_vector) {
                case 0 :  /*  Velocity field  */
                    x2=width-2;
                    y2=10;
                    l=z->legend_vect*z->scale_vect*ax;
                    x1=x2-(l);
                    y1=y2;
                    DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                    for (i=0; i<z->npoints; i++) {
                        if (z->keep_vector[i]) {
                            x1=ax*z->pos_points[0][i]+bx;
                            y1=ay*z->pos_points[1][i]+by;
                            x=z->vel_points[0][i]*ax;
                            y=z->vel_points[1][i]*ay;
                            l=sqrt(x*x+y*y);
                            if (l) {
                                cosa=x/l;
                                sina=y/l;
                                }
                            else {
                                cosa=0.;
                                sina=0.;
                                }
                            x=z->vel_points[0][i];
                            y=z->vel_points[1][i];
                            l=sqrt(x*x+y*y)*z->scale_vect*ax;
                            x2=x1+(l*cosa);
                            y2=y1+(l*sina);
                            DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                            }
                        }
                    break;
                case 1 :  /*  displacement field  */
                    x2=width-2;
                    y2=10;
                    l=z->legend_vect*z->scale_vect*ax;
                    x1=x2-(l);
                    y1=y2;
                    DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                    for (i=0; i<z->npoints; i++) {
                        if (z->keep_vector[i]) {
                            x1=ax*z->pos_points[0][i]+bx;
                            y1=ay*z->pos_points[1][i]+by;
                            x=z->disp_points[0][i]*ax;
                            y=z->disp_points[1][i]*ay;
                            l=sqrt(x*x+y*y);
                            if (l) {
                                cosa=x/l;
                                sina=y/l;
                                }
                            else {
                                cosa=0.;
                                sina=0.;
                                }
                            x=z->disp_points[0][i];
                            y=z->disp_points[1][i];
                            l=sqrt(x*x+y*y)*z->scale_vect*ax;
                            x2=x1+(l*cosa);
                            y2=y1+(l*sina);
                            DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                            }
                        }
                    break;
                case 2 :  /*  thermal flux  */
                    x2=width-2;
                    y2=10;
                    l=z->legend_vect*z->scale_vect*ax;
                    x1=x2-(l);
                    y1=y2;
                    DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                    for (i=0; i<z->nelem; i++) {
                        if (z->keep_vector[i]) {
                            center_of_elem(num_zone, i, &x, &y);
                            x1=ax*x+bx;
                            y1=ay*y+by;
                            x=z->values[10][i]*ax;
                            y=z->values[11][i]*ay;
                            l=sqrt(x*x+y*y);
                            if (l) {
                                cosa=x/l;
                                sina=y/l;
                                }
                            else {
                                cosa=0.;
                                sina=0.;
                                }
                            x=z->values[10][i];
                            y=z->values[11][i];
                            l=sqrt(x*x+y*y)*z->scale_vect*ax;
                            x2=x1+(l*cosa);
                            y2=y1+(l*sina);
                            DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                            }
                        }
                    break;
                case 3 :  /*  main stresses  */
                case 4 :  /*  main deviatoric stresses  */
                    x2=width-2;
                    y2=10;
                    l=z->legend_vect*z->scale_vect*ax/2.;
                    x1=x2-(l);
                    y1=y2;
                    x3=x1-(l);
                    y3=y1;
                    DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                    DrawArrow(dpy, win, gc, x1, y1, x3, y3);
                    for (i=0; i<z->nelem; i++) {
                        if (z->keep_vector[i]) {
                            center_of_elem(num_zone, i, &x0, &y0);
                            x1=ax*x0+bx;
                            y1=ay*y0+by;
                            cosa=cos(z->values[21][i])*ax;
                            sina=sin(z->values[21][i])*ay;
                            s=sqrt(cosa*cosa+sina*sina);
                            cosa/=s;
                            sina/=s;
                            s=z->values[18][i];
                            if (z->ploted_vector == 4)
                                s-=z->values[0][i];
                            s=s*z->scale_vect*ax;
                            s_cosa=s*cosa/2.;
                            s_sina=s*sina/2.;
                            x2=x1+s_cosa;
                            y2=y1+s_sina;
                            x3=x1-s_cosa;
                            y3=y1-s_sina;
                            if (s<0.) {
                                DrawArrow(dpy, win, gc, x2, y2, x1, y1);
                                DrawArrow(dpy, win, gc, x3, y3, x1, y1);
                                }
                            else {
                                DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                                DrawArrow(dpy, win, gc, x1, y1, x3, y3);
                                }
                            cosa=-sin(z->values[21][i])*ax;
                            sina=cos(z->values[21][i])*ay;
                            s=sqrt(cosa*cosa+sina*sina);
                            cosa/=s;
                            sina/=s;
                            s=z->values[19][i];
                            if (z->ploted_vector == 4)
                                s-=z->values[0][i];
                            s=s*z->scale_vect*ax;
                            s_cosa=s*cosa/2.;
                            s_sina=s*sina/2.;
                            x2=x1+s_cosa;
                            y2=y1+s_sina;
                            x3=x1-s_cosa;
                            y3=y1-s_sina;
                            XDrawLine(dpy, win, gc, x3, y3, x2, y2);
                            if (s<0.) {
                                DrawArrow(dpy, win, gc, x2, y2, x1, y1);
                                DrawArrow(dpy, win, gc, x3, y3, x1, y1);
                                }
                            else {
                                DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                                DrawArrow(dpy, win, gc, x1, y1, x3, y3);
                                }

                            }
                        }
                    break;
                case 5 :  /*  Direction and mode of bifurcation */
                    for (i=0; i<z->nelem; i++) {
                        if (z->keep_vector[i]) {
                            center_of_elem(num_zone, i, &x, &y);
                            x1=ax*x+bx;
                            y1=ay*y+by;
                            x=z->values[14][i]*ax;
                            y=z->values[15][i]*ay;
                            l=sqrt(x*x+y*y);
                            if (l) {
                                cosa=x/l;
                                sina=y/l;
                                }
                            else {
                                cosa=0.;
                                sina=0.;
                                }
                            x=z->values[14][i];
                            y=z->values[15][i];
                            l=sqrt(x*x+y*y)*z->scale_vect*ax;
                            x2=x1+(l*cosa);
                            y2=y1+(l*sina);
                            DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                            x=z->values[16][i]*ax;
                            y=z->values[17][i]*ay;
                            l=sqrt(x*x+y*y);
                            if (l) {
                                cosa=x/l;
                                sina=y/l;
                                }
                            else {
                                cosa=0.;
                                sina=0.;
                                }
                            x=z->values[16][i];
                            y=z->values[17][i];
                            l=sqrt(x*x+y*y)*z->scale_vect*ax;
                            x2=x1+(l/2.*cosa);
                            y2=y1+(l/2.*sina);
                            x1=x1-(l/2.*cosa);
                            y1=y1-(l/2.*sina);
                            DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                            }
                        }
                    break;
                case 6 :  /*  main strain axes  */
                    x2=width-2;
                    y2=10;
                    l=z->legend_vect*z->scale_vect*ax/2.;
                    x1=x2-(l);
                    y1=y2;
                    x3=x1-(l);
                    y3=y1;
                    DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                    DrawArrow(dpy, win, gc, x1, y1, x3, y3);
                    for (i=0; i<z->nelem; i++) {
                        if (z->keep_vector[i]) {
                            center_of_elem(num_zone, i, &x0, &y0);
                            x1=ax*x0+bx;
                            y1=ay*y0+by;
                            cosa=cos(z->values[26][i])*ax;
                            sina=sin(z->values[26][i])*ay;
                            s=sqrt(cosa*cosa+sina*sina);
                            cosa/=s;
                            sina/=s;
                            s=z->values[23][i];
/*                            if (z->ploted_vector == 4)
                                s-=z->values[0][i]; */
                            s=s*z->scale_vect*ax;
                            s_cosa=s*cosa/2.;
                            s_sina=s*sina/2.;
                            x2=x1+s_cosa;
                            y2=y1+s_sina;
                            x3=x1-s_cosa;
                            y3=y1-s_sina;
                            if (s<0.) {
                                DrawArrow(dpy, win, gc, x2, y2, x1, y1);
                                DrawArrow(dpy, win, gc, x3, y3, x1, y1);
                                }
                            else {
                                DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                                DrawArrow(dpy, win, gc, x1, y1, x3, y3);
                                }
                            cosa=-sin(z->values[26][i])*ax;
                            sina=cos(z->values[26][i])*ay;
                            s=sqrt(cosa*cosa+sina*sina);
                            cosa/=s;
                            sina/=s;
                            s=z->values[24][i];
/*                            if (z->ploted_vector == 4)
                                s-=z->values[0][i]; */
                            s=s*z->scale_vect*ax;
                            s_cosa=s*cosa/2.;
                            s_sina=s*sina/2.;
                            x2=x1+s_cosa;
                            y2=y1+s_sina;
                            x3=x1-s_cosa;
                            y3=y1-s_sina;
                            XDrawLine(dpy, win, gc, x3, y3, x2, y2);
                            if (s<0.) {
                                DrawArrow(dpy, win, gc, x2, y2, x1, y1);
                                DrawArrow(dpy, win, gc, x3, y3, x1, y1);
                                }
                            else {
                                DrawArrow(dpy, win, gc, x1, y1, x2, y2);
                                DrawArrow(dpy, win, gc, x1, y1, x3, y3);
                                }

                            }
                        }
                    break;

                }
            free(liste_points);
            }
        }
/******** plot mesh *****************************/
    if ((z->plot_mesh) && (z->nelem)) {
        liste_points=malloc(sizeof(XPoint)*(z->nodes_by_elem+1));
        if (!liste_points) {
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            }
        else {
            for (i=0; i<z->nelem; i++) {
                for (j=0; j<z->nodes_by_elem; j++) {
                    k=z->nodes_elem[j][i]-1;
                    liste_points[j].x=ax*z->pos_points[0][k]+bx;
                    liste_points[j].y=ay*z->pos_points[1][k]+by;
                    }
                liste_points[j].x=liste_points[0].x;
                liste_points[j].y=liste_points[0].y;
                XDrawLines(dpy, win, gc, liste_points, z->nodes_by_elem+1,
                           CoordModeOrigin);
                }
            free(liste_points);
            }
        }

/******** plot contour *****************************/
    if ((z->plot_contour) && (z->n_pt_contour)) {
        i=0;
        while ((i<z->n_pt_contour) && ((j=z->pt_contour[i]-1)<0)) i++;
        if (i<z->n_pt_contour) {
            x1=ax*z->pos_points[0][j]+bx;
            y1=ay*z->pos_points[1][j]+by;
            for (i++; i<z->n_pt_contour; i++) {
                j=z->pt_contour[i]-1;
                if (j>=0) {
                    x2=ax*z->pos_points[0][j]+bx;
                    y2=ay*z->pos_points[1][j]+by;
                    XDrawLine(dpy, win, gc, x1, y1, x2, y2);
                    x1=x2;
                    y1=y2;
                    }
                else {
                    while ((i<z->n_pt_contour) && ((j=z->pt_contour[i]-1)<0))
                        i++;
                    if (i<z->n_pt_contour) {
                        j=z->pt_contour[i]-1;
                        x1=ax*z->pos_points[0][j]+bx;
                        y1=ay*z->pos_points[1][j]+by;
                        }
                    }
                }
            }
        }

/******** plot highlighted elements ****************/
    if (z->nhighlight) {
        liste_points=malloc(sizeof(XPoint)*(z->nodes_by_elem+1));
        if (!liste_points) {
            nargu=0;
            sprintf(buf, "Unable to allocate memory");
            provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
            XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
            XtSetValues(Werror, argu, nargu);
            XtManageChild(Werror);
            XmStringFree(provis);
            }
        else {
            XSetForeground(dpy, gc, highlight.pixel);
            for (i=0; i<z->nhighlight; i++) {
                for (j=0; j<z->nodes_by_elem; j++) {
                    k=z->nodes_elem[j][z->list_highlight[i]]-1;
                    liste_points[j].x=ax*z->pos_points[0][k]+bx;
                    liste_points[j].y=ay*z->pos_points[1][k]+by;
                    }
                liste_points[j].x=liste_points[0].x;
                liste_points[j].y=liste_points[0].y;
                if (z->highlight_contour)
                    XDrawLines(dpy, win, gc, liste_points, z->nodes_by_elem+1,
                               CoordModeOrigin);
                else
                    XFillPolygon(dpy, win, gc, liste_points, z->nodes_by_elem,
                           Convex, CoordModeOrigin);
                }
            free(liste_points);
            XSetForeground(dpy, gc, black.pixel);
            }
        }

/******** plot grilleH ****************/
    if (z->plotGrilleH) {
        XSetForeground(dpy, gc, grille.pixel);
        for (i=0; i<nLignesH; i++) {
            for (j=0; j<LigneH[i].nSeg; j++) {
                x=z->pos_points[0][LigneH[i].Segment[j].noeud[0]];
                x=x+LigneH[i].Segment[j].prop[0]*
                  (z->pos_points[0][LigneH[i].Segment[j].noeud[1]]-x);
                y=z->pos_points[1][LigneH[i].Segment[j].noeud[0]];
                y=y+LigneH[i].Segment[j].prop[0]*
                  (z->pos_points[1][LigneH[i].Segment[j].noeud[1]]-y);
                x1=ax*x+bx;
                y1=ay*y+by;
                x=z->pos_points[0][LigneH[i].Segment[j].noeud[2]];
                x=x+LigneH[i].Segment[j].prop[1]*
                  (z->pos_points[0][LigneH[i].Segment[j].noeud[3]]-x);
                y=z->pos_points[1][LigneH[i].Segment[j].noeud[2]];
                y=y+LigneH[i].Segment[j].prop[1]*
                  (z->pos_points[1][LigneH[i].Segment[j].noeud[3]]-y);
                x2=ax*x+bx;
                y2=ay*y+by;
                XDrawLine(dpy, win, gc, x1, y1, x2, y2);
                }
            }
        }

/******** plot grilleV ****************/
    if (z->plotGrilleV) {
        XSetForeground(dpy, gc, grille.pixel);
        for (i=0; i<nLignesV; i++) {
            for (j=0; j<LigneV[i].nSeg; j++) {
                x=z->pos_points[0][LigneV[i].Segment[j].noeud[0]];
                x=x+LigneV[i].Segment[j].prop[0]*
                  (z->pos_points[0][LigneV[i].Segment[j].noeud[1]]-x);
                y=z->pos_points[1][LigneV[i].Segment[j].noeud[0]];
                y=y+LigneV[i].Segment[j].prop[0]*
                  (z->pos_points[1][LigneV[i].Segment[j].noeud[1]]-y);
                x1=ax*x+bx;
                y1=ay*y+by;
                x=z->pos_points[0][LigneV[i].Segment[j].noeud[2]];
                x=x+LigneV[i].Segment[j].prop[1]*
                  (z->pos_points[0][LigneV[i].Segment[j].noeud[3]]-x);
                y=z->pos_points[1][LigneV[i].Segment[j].noeud[2]];
                y=y+LigneV[i].Segment[j].prop[1]*
                  (z->pos_points[1][LigneV[i].Segment[j].noeud[3]]-y);
                x2=ax*x+bx;
                y2=ay*y+by;
                XDrawLine(dpy, win, gc, x1, y1, x2, y2);
                }
            }
        }


    XFreeGC(dpy, gc);

}
