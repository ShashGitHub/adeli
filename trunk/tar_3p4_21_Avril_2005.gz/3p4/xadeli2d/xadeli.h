#define PI 3.1415927
#define MAX_ZONES 10
#define DIM_BUF 500
#define N_COUL 10

EXTERN Widget Wmain, Wpaned;
EXTERN Widget Wload, Werror;
EXTERN Widget Waxes, Wsteps, Wvalues, Whighlight, Wgrille;
EXTERN XColor red, black, palette[N_COUL], highlight, grille;

EXTERN char buf[DIM_BUF];

EXTERN char *filename;
EXTERN FILE *file_in;
EXTERN long *pos_time_step;
EXTERN int time_steps_read, max_time_steps;
EXTERN int nzones, active_zone;
EXTERN float xmin, xmax, xtick, xlabel;
EXTERN float ymin, ymax, ytick, ylabel;
EXTERN float xlen, ylen;
EXTERN float ch_unit;
EXTERN int print_color;

EXTERN int nvar, nvect;
EXTERN char **name_of_var, **name_of_vect;

typedef struct {
    Widget w;
    int nstep;
    double time;
    int dim_esp;
    int nodes_by_elem;
    int npoints;
    float **pos_points;
    float **vel_points;
    float **disp_points;
    float *max_pos, *min_pos;
    int nelem;
    int **nodes_elem;
    int n_pt_contour;
    int *pt_contour;
    float **values;
    char plot_contour;
    char plot_mesh;
    char smooth_print;
    int ploted_scalar;
    int ploted_vector;
    float val_min, val_max;
    char *keep_vector;
    float scale_vect;
    float decimation_distx;
    float decimation_disty;
    float legend_vect;
    int clip_vect;
    float units_mul_scalar;
    float units_mul_vector;
    int *list_highlight;
    int nhighlight;
    int nhighlightmax;
    char highlight_contour;
    int plotGrilleV, plotGrilleH;
    } ZONE;
/*************************************************
   si on change ZONE, changer :
      initialize_zone() dans load_pfile.c
      param_delete_zone() dans param_add_zone.c  
*************************************************/

EXTERN ZONE zone[MAX_ZONES];

typedef struct {
    int noeud[4];
    double prop[2];
    } SEGMENT;
typedef struct {
    int nSeg, nSegMax;
    SEGMENT *Segment;
    } LIGNE;
EXTERN int nLignesV, nLignesH;
EXTERN LIGNE *LigneH, *LigneV;
EXTERN double xminH, xmaxH, yminH, ymaxH, interH;
EXTERN double xminV, xmaxV, yminV, ymaxV, interV;


void load_pfile(Widget, caddr_t, caddr_t);
void ok_load(Widget, caddr_t, caddr_t);
void cancel_load(Widget, caddr_t, caddr_t);
void initialize(void);
void initialize_zone(int zone, int keep_some);
void load_step(int step, int keep_some);
int skip_step(void);
void read_topo(void);

void generate_GMT_script(Widget, caddr_t, caddr_t);
void quitter(Widget, caddr_t, caddr_t);

void param_axes(Widget, caddr_t, caddr_t);
void param_time_steps(Widget, caddr_t, caddr_t);
void param_ploted_values(Widget, caddr_t, caddr_t);
void param_highlight(Widget, caddr_t, caddr_t);
void param_grille(Widget, caddr_t, caddr_t);
void fill_lists(void);
void update_values(void);
void update_highlight(void);
void update_grille(void);
void param_add_zone(Widget, caddr_t, caddr_t);
void param_delete_zone(Widget, caddr_t, caddr_t);

void affi_zone(Widget, caddr_t, caddr_t);
void center_of_elem(int nzone, int i, double *x, double *y);
void do_affi(int num_zone, Widget w);
void input_zone(Widget, caddr_t, caddr_t);

void Create_zone(void);

Widget CWaxesDialog(Widget parent);
Widget CWstepsDialog(Widget parent);
Widget CWvaluesDialog(Widget parent);
