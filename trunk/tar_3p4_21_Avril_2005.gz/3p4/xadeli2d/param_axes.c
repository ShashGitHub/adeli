#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>
#include <Xm/TextF.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"

Widget Wxmin, Wxmax, Wxtick, Wxlabel, Wymin, Wymax, Wytick, Wylabel, Wkm, Wm;
Widget Wxlen, Wylen, Wcolor, Wbw;



void param_axes(Widget w, caddr_t donnees, caddr_t appels)
{
    sprintf(buf, "%10.2f", xmin*ch_unit);
    XmTextFieldSetString(Wxmin, buf);
    sprintf(buf, "%10.2f", xmax*ch_unit);
    XmTextFieldSetString(Wxmax, buf);
    sprintf(buf, "%10.2f", xtick*ch_unit);
    XmTextFieldSetString(Wxtick, buf);
    sprintf(buf, "%10.2f", xlabel*ch_unit);
    XmTextFieldSetString(Wxlabel, buf);
    sprintf(buf, "%10.2f", ymin*ch_unit);
    XmTextFieldSetString(Wymin, buf);
    sprintf(buf, "%10.2f", ymax*ch_unit);
    XmTextFieldSetString(Wymax, buf);
    sprintf(buf, "%10.2f", ytick*ch_unit);
    XmTextFieldSetString(Wytick, buf);
    sprintf(buf, "%10.2f", ylabel*ch_unit);
    XmTextFieldSetString(Wylabel, buf);
    if (ch_unit ==1.0) {
        XmToggleButtonSetState(Wm, True, False);
        XmToggleButtonSetState(Wkm, False, False);
        }
    else {
        XmToggleButtonSetState(Wkm, True, False);
        XmToggleButtonSetState(Wm, False, False);
        }
    if (print_color) {
        XmToggleButtonSetState(Wcolor, True, False);
        XmToggleButtonSetState(Wbw, False, False);
        }
    else {
        XmToggleButtonSetState(Wbw, True, False);
        XmToggleButtonSetState(Wcolor, False, False);
        }
    sprintf(buf, "%10.2f", xlen);
    XmTextFieldSetString(Wxlen, buf);
    sprintf(buf, "%10.2f", ylen);
    XmTextFieldSetString(Wylen, buf);


    XtManageChild(Waxes);
}


/*  Callback pour le bouton apply */
void apply_axes(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    Arg argu[3];
    int nargu, i;
    char *buf2;
    XmString provis;

    i=XmToggleButtonGetState(Wkm);
    if (i)
        ch_unit=0.001;
    else
        ch_unit=1.0;
    print_color=XmToggleButtonGetState(Wcolor);
    buf2=XmTextFieldGetString(Wxmin);
    sscanf(buf2, "%f", &xmin);
    xmin/=ch_unit;
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wxmax);
    sscanf(buf2, "%f", &xmax);
    xmax/=ch_unit;
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wxtick);
    sscanf(buf2, "%f", &xtick);
    xtick/=ch_unit;
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wxlabel);
    sscanf(buf2, "%f", &xlabel);
    xlabel/=ch_unit;
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wymin);
    sscanf(buf2, "%f", &ymin);
    ymin/=ch_unit;
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wymax);
    sscanf(buf2, "%f", &ymax);
    ymax/=ch_unit;
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wytick);
    sscanf(buf2, "%f", &ytick);
    ytick/=ch_unit;
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wylabel);
    sscanf(buf2, "%f", &ylabel);
    ylabel/=ch_unit;
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wxlen);
    sscanf(buf2, "%f", &xlen);
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wylen);
    sscanf(buf2, "%f", &ylen);
    XtFree(buf2);

    for (i=0; i<nzones; i++)
        do_affi(i, zone[i].w);
}

/*  Callback pour le bouton close */
void close_axes(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    XtUnmanageChild(Waxes);
}


/*  Callback pour le bouton auto */
void auto_axes(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    int i;

    i=XmToggleButtonGetState(Wkm);
    if (i)
        ch_unit=0.001;
    else
        ch_unit=1.0;
    if (!zone[0].dim_esp) return;
    xmin=zone[0].min_pos[0];
    xmax=zone[0].max_pos[0];
    ymin=zone[0].min_pos[1];
    ymax=zone[0].max_pos[1];
    for (i=1; i<nzones; i++) {
        if (xmin>zone[i].min_pos[0])
            xmin=zone[i].min_pos[0];
        if (xmax<zone[i].max_pos[0])
            xmax=zone[i].max_pos[0];
        if (ymin>zone[i].min_pos[1])
            ymin=zone[i].min_pos[1];
        if (ymax<zone[i].max_pos[1])
            ymax=zone[i].max_pos[1];
        }
    xtick=floor((xmax-xmin)/10.);
    xlabel=floor((xmax-xmin)/5.);
    ytick=floor((ymax-ymin)/10.);
    ylabel=floor((ymax-ymin)/5.);

    sprintf(buf, "%10.2f", xmin*ch_unit);
    XmTextFieldSetString(Wxmin, buf);
    sprintf(buf, "%10.2f", xmax*ch_unit);
    XmTextFieldSetString(Wxmax, buf);
    sprintf(buf, "%10.2f", xtick*ch_unit);
    XmTextFieldSetString(Wxtick, buf);
    sprintf(buf, "%10.2f", xlabel*ch_unit);
    XmTextFieldSetString(Wxlabel, buf);
    sprintf(buf, "%10.2f", ymin*ch_unit);
    XmTextFieldSetString(Wymin, buf);
    sprintf(buf, "%10.2f", ymax*ch_unit);
    XmTextFieldSetString(Wymax, buf);
    sprintf(buf, "%10.2f", ytick*ch_unit);
    XmTextFieldSetString(Wytick, buf);
    sprintf(buf, "%10.2f", ylabel*ch_unit);
    XmTextFieldSetString(Wylabel, buf);
}



Widget CWaxesDialog(Widget wparent)
{
    Widget Wdlg, Wl1, Wl2, Wl3, Wl4, Wl5, Wl6, Wl7, Wl8, Wapply, Wclose, Wauto;
    Widget Wradio, Wl9, Wl10, Wradio2;
    Arg argu[7];
    int nargu;
    XmString provis;

    nargu=0;
    sprintf(buf, "Axes parameters");
    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(argu[nargu], XmNdialogTitle, provis); nargu++;
    XtSetArg(argu[nargu], XmNhorizontalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNverticalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNautoUnmanage, False); nargu++;
    Wdlg=XmCreateFormDialog(wparent, "Axes parameters", argu, nargu);
    XmStringFree(provis);
    nargu=0;
    XtSetArg(argu[nargu], XmNallowResize, TRUE); nargu++;
    Wl1=CWlabel(Wdlg, "label 1", "x min : ", argu, nargu);
    Wl2=CWlabel(Wdlg, "label 2", "x max : ", argu, nargu);
    Wl3=CWlabel(Wdlg, "label 3", "x ticks  : ", argu, nargu);
    Wl4=CWlabel(Wdlg, "label 4", "x labels : ", argu, nargu);
    Wl5=CWlabel(Wdlg, "label 5", "y min : ", argu, nargu);
    Wl6=CWlabel(Wdlg, "label 6", "y max : ", argu, nargu);
    Wl7=CWlabel(Wdlg, "label 7", "y ticks  : ", argu, nargu);
    Wl8=CWlabel(Wdlg, "label 8", "y labels : ", argu, nargu);
    Wl9=CWlabel(Wdlg, "label 9", "x len : ", argu, nargu);
    Wl10=CWlabel(Wdlg, "label 10", "y len    : ", argu, nargu);
    Wapply=CWboutonP(Wdlg, "Apply", argu, nargu, apply_axes);
    Wauto=CWboutonP(Wdlg, "Auto", argu, nargu, auto_axes);
    Wclose=CWboutonP(Wdlg, "Close", argu, nargu, close_axes);
    Wxmin=CWtext(Wdlg, "xmin", 10, argu, nargu);
    Wxmax=CWtext(Wdlg, "xmax", 10, argu, nargu);
    Wxtick=CWtext(Wdlg, "xtick", 10, argu, nargu);
    Wxlabel=CWtext(Wdlg, "xlabel", 10, argu, nargu);
    Wymin=CWtext(Wdlg, "ymin", 10, argu, nargu);
    Wymax=CWtext(Wdlg, "ymax", 10, argu, nargu);
    Wytick=CWtext(Wdlg, "ytick", 10, argu, nargu);
    Wylabel=CWtext(Wdlg, "ylabel", 10, argu, nargu);
    Wxlen=CWtext(Wdlg, "xlen", 10, argu, nargu);
    Wylen=CWtext(Wdlg, "ylen", 10, argu, nargu);
    nargu=1;
    XtSetArg(argu[nargu], XmNorientation, XmHORIZONTAL); nargu++;
    Wradio=XmCreateRadioBox(Wdlg, "radio", argu, nargu);
    provis=XmStringCreate("Km", XmFONTLIST_DEFAULT_TAG);
    nargu=1;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wkm=XmCreateToggleButton(Wradio, "Km", argu, nargu);
    XmStringFree(provis);
    provis=XmStringCreate("m", XmFONTLIST_DEFAULT_TAG);
    nargu=1;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wm=XmCreateToggleButton(Wradio, "m", argu, nargu);
    XmStringFree(provis);
    nargu=1;
    XtSetArg(argu[nargu], XmNorientation, XmHORIZONTAL); nargu++;
    Wradio2=XmCreateRadioBox(Wdlg, "radio", argu, nargu);
    provis=XmStringCreate("Color", XmFONTLIST_DEFAULT_TAG);
    nargu=1;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wcolor=XmCreateToggleButton(Wradio2, "Color", argu, nargu);
    XmStringFree(provis);
    provis=XmStringCreate("B/W", XmFONTLIST_DEFAULT_TAG);
    nargu=1;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Wbw=XmCreateToggleButton(Wradio2, "BW", argu, nargu);
    XmStringFree(provis);
    XtManageChild(Wradio);
    XtManageChild(Wkm);
    XtManageChild(Wm);
    XtManageChild(Wradio2);
    XtManageChild(Wcolor);
    XtManageChild(Wbw);


/*  regle la position des elements  */
    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl1, argu, nargu);
    nargu=1;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl1); nargu++;
    XtSetValues(Wxmin, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftWidget, Wxmin); nargu++;
    XtSetValues(Wl3, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftWidget, Wl3); nargu++;
    XtSetValues(Wxtick, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wxmin); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl2, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl2); nargu++;
    XtSetValues(Wxmax, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wxmax); nargu++;
    XtSetValues(Wl4, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl4); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wxlabel, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wxmax); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl5, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl5); nargu++;
    XtSetValues(Wymin, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wymin); nargu++;
    XtSetValues(Wl7, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl7); nargu++;
    XtSetValues(Wytick, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wymin); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl6, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl6); nargu++;
    XtSetValues(Wymax, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wymax); nargu++;
    XtSetValues(Wl8, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl8); nargu++;
    XtSetValues(Wylabel, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wymax); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wradio, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wradio2, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wradio); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl9, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl9); nargu++;
    XtSetValues(Wxlen, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wxlen); nargu++;
    XtSetValues(Wl10, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl10); nargu++;
    XtSetValues(Wylen, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wxlen); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wapply, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wclose, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wapply); nargu++;
    XtSetValues(Wauto, argu, nargu);

    return(Wdlg);
}
