#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"

void input_zone(Widget w, caddr_t donnees, caddr_t appels)
{
    int i, num_zone;
    Display *dpy;
    Window win;
    XGCValues gcv;
    GC gc;
    unsigned long gcmask;
    Dimension height, width;
    XFontStruct *pol_prop;
    GContext gc_id;
    Arg argu[4];
    int nargu;
    XmString provis;
    int height_char, length_str, tmp_len, tmp_len2;

    num_zone=-1;
    for (i=0; i<nzones; i++)
        if (zone[i].w == w)
            num_zone=i;
    if ((num_zone < 0) || (num_zone==active_zone)) return;

    dpy=XtDisplay(zone[active_zone].w);
    win=XtWindow(zone[active_zone].w);
    nargu=0;
    XtSetArg(argu[nargu], XmNheight, &height); nargu++;
    XtSetArg(argu[nargu], XmNwidth, &width); nargu++;
    XtGetValues(zone[active_zone].w, argu, nargu);
    gcv.line_width=1;
    gcv.function=GXcopy;
    gcmask=GCLineWidth | GCFunction;
    gc=XCreateGC(dpy, win, gcmask, &gcv);
    gc_id=XGContextFromGC(gc);
    pol_prop=XQueryFont(dpy, gc_id);
    height_char=pol_prop->ascent+pol_prop->descent;
    sprintf(buf, "step %d, t = %ld years",
              zone[active_zone].nstep,
              (long)(zone[active_zone].time/3600./24./365.25));
    length_str=XTextWidth(pol_prop, buf, strlen(buf));
    XSetForeground(dpy, gc, black.pixel);
    XDrawString(dpy, win, gc, (width-length_str)/2, pol_prop->ascent+2,
                buf, strlen(buf));
    XFreeGC(dpy, gc);

    dpy=XtDisplay(zone[num_zone].w);
    win=XtWindow(zone[num_zone].w);
    nargu=0;
    XtSetArg(argu[nargu], XmNheight, &height); nargu++;
    XtSetArg(argu[nargu], XmNwidth, &width); nargu++;
    XtGetValues(zone[num_zone].w, argu, nargu);
    gcv.line_width=1;
    gcv.function=GXcopy;
    gcmask=GCLineWidth | GCFunction;
    gc=XCreateGC(dpy, win, gcmask, &gcv);
    gc_id=XGContextFromGC(gc);
    pol_prop=XQueryFont(dpy, gc_id);
    height_char=pol_prop->ascent+pol_prop->descent;
    sprintf(buf, "step %d, t = %ld years",
              zone[num_zone].nstep,
              (long)(zone[num_zone].time/3600./24./365.25));
    length_str=XTextWidth(pol_prop, buf, strlen(buf));
    XSetForeground(dpy, gc, red.pixel);
    XDrawString(dpy, win, gc, (width-length_str)/2, pol_prop->ascent+2,
                buf, strlen(buf));
    XFreeGC(dpy, gc);

    active_zone=num_zone;
    update_values();
    update_grille();
}
