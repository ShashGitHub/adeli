#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/PanedW.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/FileSB.h>
#include <Xm/ToggleB.h>
#include <Xm/TextF.h>
#include <Xm/List.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <values.h>
#include <string.h>

#define EXTERN extern
#include "xadeli.h"

Widget Wlist_highlight, Whighlight_contour, Wred, Wgreen, Wblue;


void param_highlight(Widget w, caddr_t donnees, caddr_t appels)
{
    XmString provis;
    Arg argu[1];
    int nargu;

    update_highlight();

    XtManageChild(Whighlight);
}



void update_highlight(void)
{
    XmString provis;
    Arg argu[1];
    int nargu, i;
    char buf2[30];

    XmToggleButtonSetState(Whighlight_contour,
           zone[active_zone].highlight_contour, False);
    strcpy(buf, "");
    for (i=0; i<zone[active_zone].nhighlight; i++) {
        sprintf(buf2, "%d", zone[active_zone].list_highlight[i]);
        strcat(buf, buf2);
        }
    XmTextFieldSetString(Wlist_highlight, buf);
    sprintf(buf, "%u", highlight.red);
    XmTextFieldSetString(Wred, buf);
    sprintf(buf, "%u", highlight.green);
    XmTextFieldSetString(Wgreen, buf);
    sprintf(buf, "%u", highlight.blue);
    XmTextFieldSetString(Wblue, buf);

}




/*  Callback pour le bouton apply */
void apply_highlight(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    int nsel, *sel;
    char *buf2, *buf3;
    Arg argu[3];
    int nargu, i;
    unsigned short red, green, blue;
    Colormap cmap;
    Display *dpy;
    XmString provis;


    zone[active_zone].highlight_contour=
         XmToggleButtonGetState(Whighlight_contour);

    buf2=XmTextFieldGetString(Wlist_highlight);
    sscanf(buf2, "%f", &(zone[active_zone].val_min));
    buf3=strtok(buf2, " ,;\t");
    zone[active_zone].nhighlight=0;
    while (buf3) {
        if (zone[active_zone].nhighlight >= zone[active_zone].nhighlightmax) {
            zone[active_zone].nhighlightmax+=20;
            zone[active_zone].list_highlight=
                     realloc(zone[active_zone].list_highlight,
                             zone[active_zone].nhighlightmax);
            if (!zone[active_zone].list_highlight) {
                nargu=0;
                sprintf(buf, "Unable to allocate memory");
                provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
                XtSetArg(argu[nargu], XmNmessageString, provis); nargu++;
                XtSetValues(Werror, argu, nargu);
                XtManageChild(Werror);
                XmStringFree(provis);
                return;
                }

            }
        zone[active_zone].list_highlight[zone[active_zone].nhighlight]=
            atoi(buf3);
        (zone[active_zone].nhighlight)++;
        buf3=strtok(NULL, " ,;\t");
        }
    XtFree(buf2);

    buf2=XmTextFieldGetString(Wred);
    red=atoi(buf2);
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wgreen);
    green=atoi(buf2);
    XtFree(buf2);
    buf2=XmTextFieldGetString(Wblue);
    blue=atoi(buf2);
    XtFree(buf2);

    if ((red==highlight.red) &&
             (green==highlight.green) &&
             (blue==highlight.blue))
        do_affi(active_zone, zone[active_zone].w);
    else {
        dpy=XtDisplay(Wmain);
        cmap=XDefaultColormap(dpy, DefaultScreen(dpy));
        highlight.red=red;
        highlight.green=green;
        highlight.blue=blue;
        highlight.flags=DoRed | DoGreen | DoBlue;
        XAllocColor(dpy, cmap, &highlight);
        for (i=0; i<nzones; i++)
            do_affi(i, zone[i].w);
        }
}

/*  Callback pour le bouton close */
void close_highlight(w, donnees, appels)
Widget w;
caddr_t donnees, appels;
{
    XtUnmanageChild(Whighlight);
}



Widget CWhighlightDialog(Widget wparent)
{
    Widget Wdlg, Wl1, Wl2, Wl3, Wl4, Wl5, Wl6, Wl7, Wl8, Wl9, Wl10;
    Widget Wauto2, Wauto, Wapply, Wclose, Wallsc, Wallve;
    Arg argu[10];
    int nargu;
    XmString provis;

    nargu=0;
    sprintf(buf, "Highlighted elements");
    provis=XmStringCreate(buf, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(argu[nargu], XmNdialogTitle, provis); nargu++;
    XtSetArg(argu[nargu], XmNhorizontalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNverticalSpacing, 3); nargu++;
    XtSetArg(argu[nargu], XmNautoUnmanage, False); nargu++;
    Wdlg=XmCreateFormDialog(wparent, "Highlight elements parameters", argu, nargu);
    XmStringFree(provis);
    nargu=0;
    XtSetArg(argu[nargu], XmNallowResize, TRUE); nargu++;
    Wl1=CWlabel(Wdlg, "label 1", "List of elements : ", argu, nargu);
    Wl2=CWlabel(Wdlg, "label 2", "Red : ", argu, nargu);
    Wl3=CWlabel(Wdlg, "label 3", "Green : ", argu, nargu);
    Wl4=CWlabel(Wdlg, "label 4", "Blue : ", argu, nargu);
    Wl5=CWlabel(Wdlg, "label 5", "Color (0-65535) : ", argu, nargu);
    Wlist_highlight=CWtext(Wdlg, "list highlight", 50, argu, nargu);
    Wred=CWtext(Wdlg, "red", 10, argu, nargu);
    Wgreen=CWtext(Wdlg, "green", 10, argu, nargu);
    Wblue=CWtext(Wdlg, "blue", 10, argu, nargu);
    Wapply=CWboutonP(Wdlg, "Apply", argu, nargu, apply_highlight);
    Wclose=CWboutonP(Wdlg, "Close", argu, nargu, close_highlight);

    provis=XmStringCreate("contour only", XmFONTLIST_DEFAULT_TAG);
    nargu=0;
    XtSetArg(argu[nargu], XmNlabelString, provis); nargu++;
    Whighlight_contour=XmCreateToggleButton(Wdlg, "highlight contour", argu, nargu);
    XtManageChild(Whighlight_contour);
    XmStringFree(provis);

/*  regle la position des elements  */
    nargu=0;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wl1, argu, nargu);
    nargu=1;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wl1); nargu++;
    XtSetValues(Wlist_highlight, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNtopWidget, Wlist_highlight); nargu++;
    XtSetValues(Whighlight_contour, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNtopWidget, Whighlight_contour); nargu++;
    XtSetValues(Wl5, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNtopWidget, Wl5); nargu++;
    XtSetValues(Wl2, argu, nargu);
    nargu=0;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wl5); nargu++;
    XtSetArg(argu[nargu], XmNleftWidget, Wl2); nargu++;
    XtSetValues(Wred, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wred); nargu++;
    XtSetValues(Wl3, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl3); nargu++;
    XtSetValues(Wgreen, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wgreen); nargu++;
    XtSetValues(Wl4, argu, nargu);
    nargu=3;
    XtSetArg(argu[nargu], XmNleftWidget, Wl4); nargu++;
    XtSetValues(Wblue, argu, nargu);

    nargu=0;
    XtSetArg(argu[nargu], XmNtopAttachment, XmATTACH_WIDGET); nargu++;
    XtSetArg(argu[nargu], XmNtopWidget, Wred); nargu++;
    XtSetArg(argu[nargu], XmNleftAttachment, XmATTACH_FORM); nargu++;
    XtSetArg(argu[nargu], XmNbottomAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wapply, argu, nargu);
    nargu=2;
    XtSetArg(argu[nargu], XmNrightAttachment, XmATTACH_FORM); nargu++;
    XtSetValues(Wclose, argu, nargu);

    return(Wdlg);
}

