#include <stdio.h>

void ffputc(char c[900][1150][2], int *npy, int *npx, char *ligne)
{
   int jy, jx;
   FILE *out;

   out=fopen(ligne, "w");
   for (jy=0; jy<*npy; jy++) {
      for (jx=0; jx<*npx; jx++) {
         fputc(c[*npy-jy-1][jx][1], out);
         }
      }
   fclose(out);
}
